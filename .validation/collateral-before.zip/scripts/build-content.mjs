import { build } from 'vite';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { basename, dirname, extname, resolve, relative, isAbsolute, sep } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { zipSync, strToU8 } from 'fflate';
import { rollup } from 'rollup';

const mediaTypes = {
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.gif': 'image/gif',
  '.avif': 'image/avif',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.ogg': 'audio/ogg',
  '.webm': 'video/webm',
  '.json': 'application/json',
  '.atlas': 'text/plain',
  '.skel': 'application/octet-stream',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
};

/** 打包普通 TS 模块，SDK 保持为宿主参数，避免复制 Window/Class 身份。 */
async function compileContent(entry, externalAssets) {
  const entryPath = resolve(entry);
  const virtualEntry = '\0sgs-content-entry';
  const authorEntry = '\0sgs-author-entry.ts';
  const resourcePrefix = '\0sgs-resource:';
  const contentPrefix = '@sgs/content/';
  const assets = new Map();
  const sourceRoot = fileURLToPath(new URL('../src/', import.meta.url));
  const sdkRoot = resolve(sourceRoot, 'sdk');
  const sdkPaths = new Set([
    sdkRoot,
    resolve(sdkRoot, 'index'),
    resolve(sdkRoot, 'index.ts'),
    resolve(sdkRoot, 'index.js'),
  ]);
  const inside = (parent, file) => {
    const path = relative(parent, file);
    return path !== '..' && !path.startsWith(`..${sep}`) && !isAbsolute(path);
  };
  const result = await build({
    root: externalAssets ? dirname(entryPath) : undefined,
    configFile: false,
    publicDir: false,
    logLevel: 'warn',
    plugins: [
      {
        name: 'sgs-content-sdk',
        enforce: 'pre',
        async resolveId(source, importer) {
          if (source === virtualEntry) return virtualEntry;
          if (source === authorEntry || source === entryPath.replaceAll('\\', '/'))
            return authorEntry;
          if (source.startsWith(contentPrefix)) {
            if (!/^[a-z][a-z0-9_-]*$/.test(source.slice(contentPrefix.length)))
              this.error(`Import a package entry: ${contentPrefix}<packageId> (${source})`);
            return { id: source, external: true };
          }
          if (!importer || (!source.startsWith('.') && !isAbsolute(source))) return;
          const parent = importer === authorEntry ? dirname(entryPath) : dirname(importer);
          const file = resolve(parent, source);
          if (sdkPaths.has(file)) return { id: '@sgs/sdk', external: true };
          if (externalAssets) {
            const [path, query] = source.split('?');
            const extension = extname(path).toLowerCase();
            if (query === 'url' || (!query && extension !== '.json' && mediaTypes[extension])) {
              const resource = resolve(parent, path);
              const bytes = await readFile(resource);
              const local = inside(dirname(entryPath), resource)
                ? relative(dirname(entryPath), resource).split(sep).join('/')
                : `_shared/${createHash('sha256').update(bytes).digest('hex')}/${basename(resource)}`;
              const assetPath = `assets/${local}`;
              assets.set(assetPath, {
                bytes,
                type: mediaTypes[extension] ?? 'application/octet-stream',
              });
              return resourcePrefix + assetPath;
            }
          }
          if (importer === authorEntry) return this.resolve(source, entryPath, { skipSelf: true });
        },
        async load(id) {
          if (id === authorEntry)
            return { code: await readFile(entryPath, 'utf8'), moduleType: 'ts' };
          if (id === virtualEntry)
            return `export { default } from ${JSON.stringify(entryPath.replaceAll('\\', '/'))}; export * from ${JSON.stringify(entryPath.replaceAll('\\', '/'))};`;
          if (id.startsWith(resourcePrefix)) {
            const path = id.slice(resourcePrefix.length);
            return `import { url } from '@sgs/assets'; export default url(${JSON.stringify(path)});`;
          }
        },
        moduleParsed(info) {
          const file = info.id.split('?')[0];
          if (isAbsolute(file) && inside(sourceRoot, file) && !inside(dirname(entryPath), file))
            this.error(
              `Content modules must import host APIs through @sgs/sdk: ${relative(sourceRoot, file)}`,
            );
        },
      },
    ],
    build: {
      target: 'es2022',
      write: false,
      minify: false,
      sourcemap: false,
      lib: { entry: entryPath, formats: ['es'] },
      rolldownOptions: {
        cwd: externalAssets ? dirname(entryPath) : undefined,
        input: virtualEntry,
        external: ['@sgs/sdk', '@sgs/assets'],
        output: {
          codeSplitting: false,
        },
      },
    },
  });
  const outputs = (Array.isArray(result) ? result : [result]).flatMap((item) => item.output ?? []);
  if (outputs.length !== 1 || outputs[0].type !== 'chunk')
    throw new Error('A content module must produce one JavaScript chunk. Inline its resources.');
  const chunk = outputs[0];
  if (chunk.dynamicImports.length)
    throw new Error('Content code dependencies must use static imports.');
  const imports = chunk.imports
    .filter((id) => id.startsWith(contentPrefix))
    .map((id) => id.slice(contentPrefix.length))
    .sort();
  // Vite 处理 TS/资源；Rollup 将单个 ESM 片段包装为参数工厂。
  // interop: esModule 直接使用真实导出对象，词法绑定与 live exports 交给编译器。
  const moduleGlobal = (id) => `__sgs_module_${Buffer.from(id).toString('hex')}`;
  const linked = await rollup({
    input: virtualEntry,
    external: chunk.imports,
    plugins: [
      {
        name: 'sgs-content-factory',
        resolveId: (id) => (id === virtualEntry ? id : null),
        load: (id) => (id === virtualEntry ? chunk.code : null),
      },
    ],
  });
  let compiled;
  try {
    const output = await linked.generate({
      format: 'iife',
      name: '__sgs_content__',
      exports: 'named',
      interop: 'esModule',
      globals: (id) =>
        id === '@sgs/sdk'
          ? 'sdk'
          : id === '@sgs/assets'
            ? 'assets'
            : moduleGlobal(id.slice(contentPrefix.length)),
    });
    compiled = output.output[0].code;
  } catch (error) {
    if (error.code === 'INVALID_TLA_FORMAT')
      throw new Error(
        'Content module initialization must be synchronous. Use await inside skill functions.',
        { cause: error },
      );
    throw error;
  } finally {
    await linked.close();
  }
  const bindings = imports
    .map((id) => `const ${moduleGlobal(id)} = modules[${JSON.stringify(id)}];`)
    .join('\n');
  const code = `// Built by sgs_ng; ordinary trusted content code.\nexport const format = 'sgs-content/1';\nexport const imports = ${JSON.stringify(imports)};\nexport function createNamespace(sdk, assets, modules) {\n${bindings}\n${compiled}\nreturn __sgs_content__;\n}\nexport default function createContent(sdk, assets, modules) { return createNamespace(sdk, assets, modules).default; }\n`;
  return { code, assets };
}

/** 单文件仍内联资源；独立资源包使用相同的普通 TS 入口。 */
export async function bundleContent(entry) {
  return (await compileContent(entry, false)).code;
}

export async function bundleContentArchive(entry) {
  const { code, assets } = await compileContent(entry, true);
  const ordered = [...assets].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  const manifest = {
    format: 'sgs-bundle/1',
    module: 'content.sgs.mjs',
    assets: ordered.map(([path, asset]) => ({ path, type: asset.type })),
  };
  // 固定 ZIP 时间与文件顺序，原始资源字节不转换、不嵌入源码。
  const files = {
    'manifest.json': strToU8(JSON.stringify(manifest)),
    'content.sgs.mjs': strToU8(code),
    ...Object.fromEntries(ordered.map(([path, asset]) => [path, asset.bytes])),
  };
  return zipSync(files, { level: 6, mtime: new Date(2000, 0, 1) });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [entry, destination] = process.argv.slice(2);
  if (!entry || !destination)
    throw new Error('Usage: pnpm content:build <entry.ts> <output.sgs.mjs | output.sgs>');
  const code = destination.endsWith('.sgs')
    ? await bundleContentArchive(entry)
    : await bundleContent(entry);
  await mkdir(dirname(resolve(destination)), { recursive: true });
  await writeFile(destination, code, typeof code === 'string' ? 'utf8' : undefined);
  console.log(`Content module: ${resolve(destination)} (${Buffer.byteLength(code)} bytes)`);
}
