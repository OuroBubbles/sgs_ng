import { build } from 'vite';

// 与客户端使用同一次内容发现规则；作者代码只在主持端执行。
await build({
  configFile: false,
  build: {
    ssr: 'src/server/main.ts',
    target: 'node24',
    outDir: '.artifacts/server',
    emptyOutDir: true,
    sourcemap: true,
    rollupOptions: { output: { entryFileNames: 'main.mjs' } },
  },
});
