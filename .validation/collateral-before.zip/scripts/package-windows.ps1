﻿# 只打包已实际验证的 Release，不构建，也不把构建成功当作原生运行证明。
$ErrorActionPreference = 'Stop'
$packageRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$releaseExe = Join-Path $packageRoot 'src-tauri/target/release/sgs-ng.exe'
$proofPath = Join-Path $packageRoot '.artifacts/ui/native-smoke-release.json'
$proof = Get-Content -LiteralPath $proofPath -Encoding utf8 -Raw | ConvertFrom-Json
$restartProof = Get-Content -LiteralPath (Join-Path $packageRoot '.artifacts/ui/native-content-restart-release.json') -Encoding utf8 -Raw | ConvertFrom-Json
$profileProof = Get-Content -LiteralPath (Join-Path $packageRoot '.artifacts/ui/native-profile-release.json') -Encoding utf8 -Raw | ConvertFrom-Json
$networkProof = Get-Content -LiteralPath (Join-Path $packageRoot '.artifacts/validation/native-network-release.json') -Encoding utf8 -Raw | ConvertFrom-Json
$releaseHash = (Get-FileHash -LiteralPath $releaseExe -Algorithm SHA256).Hash.ToLowerInvariant()
$modulePath = Join-Path $packageRoot '.artifacts/content/harbor.sgs.mjs'
$moduleHash = (Get-FileHash -LiteralPath $modulePath -Algorithm SHA256).Hash.ToLowerInvariant()
$resourcePath = Join-Path $packageRoot '.artifacts/content/gallery.sgs'
$resourceHash = (Get-FileHash -LiteralPath $resourcePath -Algorithm SHA256).Hash.ToLowerInvariant()
if ($proof.externalResourceBundle.sha256 -ne $resourceHash -or $restartProof.resourceBundleSha256 -ne $resourceHash -or
  !$restartProof.restoredResourceBlob -or !$restartProof.resourceGuestRealHostSkillAndPortrait) {
  throw 'Binary resource bundle has no matching real native restart proof.'
}
if ($proof.buildKind -ne 'release' -or $proof.executable -ne $releaseExe -or
  $proof.executableSha256 -ne $releaseHash -or $proof.consoleErrors.Count -ne 0) {
  throw 'Release proof does not match this executable.'
}
if ($networkProof.executableSha256 -ne $releaseHash -or !$networkProof.returnedOffline -or !$networkProof.hiddenAndRestored -or
  !$networkProof.delegationHandoff -or !$networkProof.delegatedToEnd -or
  $networkProof.processIds.Count -ne 2 -or $networkProof.acted.Count -ne 2 -or $networkProof.acted[0] -lt 1 -or $networkProof.acted[1] -lt 1 -or
  !$networkProof.result -or $networkProof.consoleErrors.Count -ne 0) {
  throw 'Release network proof is missing or stale.'
}
if ($proof.externalModule.file -ne '.artifacts/content/harbor.sgs.mjs' -or $proof.externalModule.sha256 -ne $moduleHash) {
  throw 'Content module differs from the native import proof.'
}
if ($restartProof.executableSha256 -ne $releaseHash -or $restartProof.moduleSha256 -ne $moduleHash -or
  $restartProof.initialProcessId -ne $proof.processId -or $restartProof.initialProcessId -eq $restartProof.restoredProcessId -or
  !$restartProof.restoredWithoutFileSelection -or !$restartProof.realHostSkillAndMaterials -or !$restartProof.clearedAfterReload -or $restartProof.consoleErrors.Count -ne 0) {
  throw 'Release process restart proof is missing or stale.'
}
if (!$profileProof.isolated -or $profileProof.checks.Count -ne 2 -or $profileProof.directory -ne $proof.verificationProfile -or
  $profileProof.directory -ne $restartProof.verificationProfile -or $profileProof.checks[0].processId -ne $proof.processId -or
  $profileProof.checks[1].processId -ne $restartProof.restoredProcessId) { throw 'Native verification did not use one isolated profile across both processes.' }

$buildRoot = Join-Path $packageRoot '.artifacts/builds'
$stageRoot = Join-Path $buildRoot 'local-client-windows'
New-Item -ItemType Directory -Path $stageRoot -Force | Out-Null
Copy-Item -LiteralPath $releaseExe -Destination (Join-Path $stageRoot 'sgs-ng.exe') -Force
Copy-Item -LiteralPath $modulePath -Destination (Join-Path $stageRoot 'harbor.sgs.mjs') -Force
Copy-Item -LiteralPath $resourcePath -Destination (Join-Path $stageRoot 'gallery.sgs') -Force
Copy-Item -LiteralPath (Join-Path $packageRoot 'public/spine/LICENSE') -Destination (Join-Path $stageRoot 'Spine-LICENSE.txt') -Force
@'
弈 · 三国杀新章 / 桌面客户端

解压后运行 sgs-ng.exe，需要 Windows WebView2 Runtime。
单机：选择武将、席位、牌组和种子后开始；固定控制甲席，其余基础 AI。本人可点击“托管”并随时“收回”；基础策略无法处理的本人请求会交还。暂停或进入后台会藏牌并停止全桌 AI，继续后保留托管选择；手动演练供内容调试。
当前标准＋EX 含 108 张实体牌、32 种牌和 25 名武将。

联机：在开局页展开“加入联机”，填写主持端地址，例如 http://192.168.1.10:1422。客户端保留本地页面，双方准备后开局；当前固定四人、两个人类和两席基础 AI。
主持端暂由源码目录的 pnpm online 启动，局域网在 PowerShell 设置 $env:SGS_HOST = '0.0.0.0'。默认只监听 127.0.0.1:1422；另一台机器填写主持机实际 IP。
联机藏牌不暂停他人或 AI，本人已开启的托管也继续执行；恢复后可收回。断线结束本局；返回单机无需联网。每个主持进程仅一局，再开需重启。尚无重连、房间列表、内容包分发或高级托管。

内容示例：开局页“导入内容包”选 harbor.sgs.mjs，启用渡口并选渡客、两人、AI 关羽、渡口演练、种子 2。使用起手备航并发动潮声，手牌净增两张。
同时导入 gallery.sgs 可启用画阁和画阁客：画阁通过普通 import 共享渡口查询与时点，自带二进制立绘。两个包和启用选择会持久保存，重启恢复。
停用/移除时会同时处理依赖它的包；恢复失败可重载或明确清空，原始内容文件不会被修改。

本包 exe 已经过实际 Windows WebView2 验收，摘要见交付清单；同机双进程联机不代替真实跨机器验收。
Spineboy 为既有运行时验证样本，许可见 Spine-LICENSE.txt；作者 Spine 支持仍后置。
'@ | Set-Content -LiteralPath (Join-Path $stageRoot 'RUNNING.txt') -Encoding utf8

$version = (Get-Content -LiteralPath (Join-Path $packageRoot 'package.json') -Encoding utf8 -Raw | ConvertFrom-Json).version
$archivePath = Join-Path $buildRoot "sgs-ng-$version-local-client-windows-x64.zip"
$members = @('sgs-ng.exe', 'Spine-LICENSE.txt', 'RUNNING.txt', 'harbor.sgs.mjs', 'gallery.sgs')
$memberPaths = $members | ForEach-Object { Join-Path $stageRoot $_ }
Compress-Archive -LiteralPath $memberPaths -DestinationPath $archivePath -Force

# 校验真正写入 ZIP 的字节及精确成员，不能只比较暂存目录或清单。
$zip = [System.IO.Compression.ZipFile]::OpenRead($archivePath)
try {
  $archiveMembers = @($zip.Entries.FullName)
  if (Compare-Object ($members | Sort-Object) ($archiveMembers | Sort-Object)) {
    throw 'Unexpected archive members.'
  }
  $exeStream = $zip.GetEntry('sgs-ng.exe').Open()
  try {
    $archivedHash = (Get-FileHash -InputStream $exeStream -Algorithm SHA256).Hash.ToLowerInvariant()
  } finally { $exeStream.Dispose() }
  if ($archivedHash -ne $releaseHash) { throw 'Archived executable differs from native proof.' }
  $moduleStream = $zip.GetEntry('harbor.sgs.mjs').Open()
  try { $archivedModuleHash = (Get-FileHash -InputStream $moduleStream -Algorithm SHA256).Hash.ToLowerInvariant() } finally { $moduleStream.Dispose() }
  if ($archivedModuleHash -ne $moduleHash) { throw 'Archived content module differs from native proof.' }
  $resourceStream = $zip.GetEntry('gallery.sgs').Open()
  try { $archivedResourceHash = (Get-FileHash -InputStream $resourceStream -Algorithm SHA256).Hash.ToLowerInvariant() } finally { $resourceStream.Dispose() }
  if ($archivedResourceHash -ne $resourceHash) { throw 'Archived resource bundle differs from native proof.' }
} finally { $zip.Dispose() }

$manifest = [ordered]@{
  capturedAt = (Get-Date).ToUniversalTime().ToString('o')
  stage = 'desktop-client-offline-and-network'
  archive = $archivePath
  bytes = (Get-Item -LiteralPath $archivePath).Length
  archiveSha256 = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant()
  executableSha256 = $releaseHash
  moduleSha256 = $moduleHash
  resourceBundleSha256 = $resourceHash
  members = $members
  nativeProof = '.artifacts/ui/native-smoke-release.json'
  contentRestartProof = '.artifacts/ui/native-content-restart-release.json'
  contentProfileProof = '.artifacts/ui/native-profile-release.json'
  networkProof = '.artifacts/validation/native-network-release.json'
}
$manifest | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $buildRoot 'local-client-manifest.json') -Encoding utf8
$manifest | ConvertTo-Json -Depth 4
