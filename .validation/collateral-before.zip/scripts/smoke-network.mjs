import { chromium, expect } from '@playwright/test';
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';

const endpoints = [process.env.SGS_NATIVE_CDP, process.env.SGS_NATIVE_PEER_CDP];
assert(endpoints.every(Boolean), 'Use pnpm desktop:network with isolated profiles.');
const buildKind = process.env.SGS_NATIVE_BUILD;
assert(['debug', 'release'].includes(buildKind));
const browsers = [];
const pages = [];
const errors = [];
const lastViews = [null, null];
const views = [0, 0];
const acted = [0, 0];
const keys = new Set();
const policies = [];
try {
  for (const [index, endpoint] of endpoints.entries()) {
    const browser = await chromium.connectOverCDP(endpoint);
    browsers.push(browser);
    const page = browser.contexts()[0].pages()[0];
    await page.waitForURL(/tauri\.localhost/);
    const response = await page.reload();
    const headers = response ? await response.allHeaders() : {};
    policies.push(
      headers['content-security-policy'] ??
        (await page
          .locator('meta[http-equiv="Content-Security-Policy"]')
          .getAttribute('content')
          .catch(() => null)),
    );
    await expect(page.getByTestId('battle-canvas').locator('canvas')).toBeVisible();
    pages.push(page);
    await page.getByRole('spinbutton').fill('0');
    page.on('pageerror', (error) => errors.push(error.message));
    page.on('console', (message) => {
      if (message.type() === 'error') errors.push(message.text());
    });
    page.on('websocket', (socket) => {
      assert.equal(socket.url(), 'ws://127.0.0.1:1422/game');
      socket.on('framereceived', ({ payload }) => {
        const message = JSON.parse(String(payload));
        if (message.kind !== 'view') return;
        views[index]++;
        lastViews[index] = message.view;
        assert.equal(message.lobby.seat, index === 0 ? '甲席' : '乙席');
        assert.equal(message.view.viewer, message.lobby.seat);
        assert.deepEqual(
          message.view.players.filter((seat) => seat.self).map((seat) => seat.id),
          [message.lobby.seat],
        );
      });
    });
    await page.getByText('加入联机', { exact: true }).click();
    await page.getByRole('textbox', { name: '主持端地址' }).fill('ftp://invalid-host');
    await page.getByRole('button', { name: '连接主持端' }).click();
    await expect(page.getByRole('alert')).toContainText('主持端地址无效');
    await page.getByRole('textbox', { name: '主持端地址' }).fill('127.0.0.1:1422');
    await page.getByRole('button', { name: '连接主持端' }).click();
    await expect(page.locator('.room-tag')).toHaveText(`联机 · ${index === 0 ? '甲席' : '乙席'}`);
    assert.match(page.url(), /tauri\.localhost/);
  }
  for (const page of pages) await page.getByRole('button', { name: '准备对局' }).click();
  let hidden = false;
  let delegationHandoff = false;
  let delegatedToEnd = false;
  const deadline = Date.now() + 240_000;
  for (let step = 0; step < 700 && Date.now() < deadline; step++) {
    if (lastViews.every((view) => view?.result)) break;
    for (const page of pages) {
      const restore = page.getByRole('button', { name: '恢复手牌', exact: true });
      if (await restore.count()) await restore.click();
      const failure = page.getByRole('region', { name: '对局中止' });
      if (await failure.count()) throw new Error(await failure.textContent());
    }
    if (!delegatedToEnd && delegationHandoff && acted.every((count) => count > 0)) {
      for (const page of pages) {
        await page.getByRole('button', { name: 'AI 托管', exact: true }).click();
        await expect(page.getByRole('button', { name: '收回操作', exact: true })).toHaveAttribute(
          'aria-pressed',
          'true',
        );
        await expect(page.locator('.decision-actions button')).toHaveCount(0);
      }
      delegatedToEnd = true;
      continue;
    }
    const states = await Promise.all(
      pages.map((page) =>
        page.evaluate(() => ({
          kind: document.querySelector('[data-decision-kind]')?.getAttribute('data-decision-kind'),
          key: document.querySelector('[data-decision-key]')?.getAttribute('data-decision-key'),
        })),
      ),
    );
    const index = states.findIndex((state) => state.kind);
    if (index < 0) {
      await new Promise((resolve) => setTimeout(resolve, 30));
      continue;
    }
    assert(!delegatedToEnd, '托管期间不应收到需要本人手动回答的请求。');
    const page = pages[index],
      state = states[index];
    const hand = page.getByTestId('hand-cards').getByRole('button');
    const confirm = page.getByRole('button', { name: '确认当前选择', exact: true });
    if (!hidden) {
      const amount = await hand.count();
      await page.getByRole('button', { name: '隐藏联机手牌', exact: true }).click();
      await expect(hand).toHaveCount(0);
      await page.getByRole('button', { name: '恢复手牌', exact: true }).click();
      await expect(hand).toHaveCount(amount);
      hidden = true;
    }
    if (!delegationHandoff && state.kind === 'play-action') {
      await page.getByRole('button', { name: 'AI 托管', exact: true }).click();
      await expect(page.getByRole('button', { name: '收回操作', exact: true })).toHaveAttribute(
        'aria-pressed',
        'true',
      );
      await page.getByRole('button', { name: '收回操作', exact: true }).click();
      await expect(page.getByRole('button', { name: 'AI 托管', exact: true })).toHaveAttribute(
        'aria-pressed',
        'false',
      );
      delegationHandoff = true;
      continue;
    }
    keys.add(state.key);
    if (state.kind === 'play-action') {
      let used = false;
      for (const card of await page
        .getByTestId('hand-cards')
        .locator('button[aria-label^="杀 "], button[aria-label^="决斗 "]')
        .all()) {
        await card.click();
        await expect(page.locator('.decision-copy small')).not.toContainText('正在核对');
        const targets = page.locator('.target-hitbox[aria-disabled="false"][aria-pressed="false"]');
        if (await targets.count()) await targets.first().click();
        await expect(page.locator('.decision-copy small')).not.toContainText('正在核对');
        if (await confirm.isEnabled()) {
          await confirm.click();
          used = true;
          break;
        }
      }
      if (!used) {
        await page.keyboard.press('Escape');
        await page.getByRole('button', { name: '结束出牌', exact: true }).click();
      }
    } else if (state.kind === 'cards-targets') {
      await expect(page.locator('.decision-copy small')).not.toContainText('正在核对');
      const prompt = await page.getByTestId('decision-hint').textContent();
      const amount = Number(prompt.match(/弃置 (\d+)/)?.[1]);
      if (amount > 0) {
        for (let item = 0; item < amount; item++) {
          await hand.nth(item).click();
          await expect(page.locator('.decision-copy small')).not.toContainText('正在核对');
        }
      } else {
        await page.locator('.public-pools button[aria-disabled="false"]').first().click();
      }
      await expect(confirm).toBeEnabled();
      await confirm.click();
    } else if (state.kind === 'invoke') {
      await page.getByRole('button', { name: '不发动', exact: true }).click();
    } else if (state.kind === 'card-response' || state.kind === 'use-card') {
      await page.locator('.decision-actions .cancel-button').click();
    } else if (state.kind === 'trigger-order' || state.kind === 'choose-option') {
      await page.locator('.decision-actions button:not([disabled])').first().click();
    } else throw new Error(`Unsupported native proof choice: ${state.kind}`);
    acted[index]++;
    await expect(page.locator('[data-decision-key]')).not.toHaveAttribute(
      'data-decision-key',
      state.key,
    );
  }
  for (const [index, page] of pages.entries()) {
    await expect(page.getByRole('region', { name: '对局结果' })).toBeVisible();
    await expect(page.locator('.decision-actions button')).toHaveCount(0);
    await expect(page.getByTestId('journal')).toContainText('对局结束');
    await page.screenshot({
      path: `.artifacts/ui/native-network-${index === 0 ? '甲' : '乙'}-${buildKind}.png`,
    });
  }
  assert(acted.every((count) => count > 0));
  assert(hidden);
  assert(delegationHandoff && delegatedToEnd);
  assert(lastViews.every((view) => view.control?.delegated));
  assert.deepEqual(lastViews[0].result, lastViews[1].result);
  for (const page of pages) {
    await page.getByRole('button', { name: /^返回单机/ }).click();
    await expect(page.getByRole('button', { name: '开始单机对局' })).toBeVisible();
    await expect(page.getByRole('spinbutton')).toHaveValue('0');
    assert.match(page.url(), /tauri\.localhost/);
  }
  assert.deepEqual(errors, []);
  const executable = process.env.SGS_NATIVE_EXE;
  const report = {
    time: new Date().toISOString(),
    buildKind,
    executable,
    executableSha256: crypto.createHash('sha256').update(fs.readFileSync(executable)).digest('hex'),
    processIds: [Number(process.env.SGS_NATIVE_PID), Number(process.env.SGS_NATIVE_PEER_PID)],
    browsers: browsers.map((browser) => browser.version()),
    origins: pages.map((page) => new URL(page.url()).origin),
    policies,
    views,
    acted,
    decisionCount: keys.size,
    result: lastViews[0].result,
    hiddenAndRestored: hidden,
    delegationHandoff,
    delegatedToEnd,
    returnedOffline: true,
    consoleErrors: errors,
    sameMachine: true,
  };
  fs.writeFileSync(
    `.artifacts/validation/native-network-${buildKind}.json`,
    JSON.stringify(report, null, 2),
  );
  console.log(
    JSON.stringify({
      buildKind,
      processIds: report.processIds,
      acted,
      result: report.result,
      returnedOffline: true,
      consoleErrors: errors,
    }),
  );
} finally {
  for (const browser of browsers) await browser.close();
}
