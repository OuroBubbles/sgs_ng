<script lang="ts">
  import type { SeatView } from '../../core/view/game';

  const { player }: { player: SeatView } = $props();
</script>

<!-- 可见文字与目标按钮共用矩形；完整语义仍由按钮的 aria-label 提供。 -->
<span class="seat-status" class:dead={!player.alive} aria-hidden="true">
  <span class="seat-role" title={player.role ?? '身份未知'}>{player.role ?? '未知'}</span>
  <span class="seat-hand" title="手牌数量">牌 <b>{player.handCount}</b></span>
  <span class="seat-name" title={player.title || player.name}>{player.title || player.name}</span>
  <span class="seat-vitals">
    <span class="health-pips">
      {#each Array.from({ length: player.maxHp }, (_, i) => i) as i (i)}<i
          class:filled={i < player.hp}
        ></i>{/each}
    </span>
    <span class="seat-health" class:danger={player.hp <= 1} title="体力"
      >{player.hp}/{player.maxHp}</span
    >
    <span class="seat-gender">{player.gender}</span>
    {#if player.alive && player.chained}<span class="seat-effect" title="连环"
        >连<span class="full-label">环</span></span
      >{/if}
    {#if player.alive && player.shield > 0}<span class="seat-effect">盾{player.shield}</span>{/if}
  </span>
  {#if player.self}<span class="seat-you">你</span>{/if}
</span>

<style>
  .seat-status {
    position: absolute;
    inset: 6px;
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    grid-template-rows: auto 1fr auto auto;
    gap: 4px;
    padding: 5px;
    color: #e0d3b9;
    background:
      linear-gradient(#081817d9, transparent 35%),
      linear-gradient(to top, #081817f5, transparent 50%);
    font:
      11px/1.2 'Microsoft YaHei',
      'PingFang SC',
      sans-serif;
    text-align: left;
  }
  .dead {
    opacity: 0.4;
  }
  .seat-role,
  .seat-name {
    min-width: 0;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .seat-role {
    color: #b5c9a9;
  }
  .seat-hand {
    white-space: nowrap;
    color: #d6c28c;
  }
  .seat-name {
    grid-column: 1 / -1;
    grid-row: 3;
    font:
      23px/1.2 KaiTi,
      STKaiti,
      SimSun,
      serif;
    text-align: center;
  }
  .seat-vitals {
    grid-column: 1 / -1;
    grid-row: 4;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
    gap: 3px;
    font-size: 11px;
  }
  .health-pips {
    display: flex;
    gap: 3px;
  }
  .health-pips i {
    width: 6px;
    height: 5px;
    border-radius: 1px;
    background: #334640;
  }
  .health-pips .filled {
    background: #8eac85;
  }
  .seat-health {
    color: #b5d2ac;
    white-space: nowrap;
  }
  .seat-health.danger {
    color: #f0a88b;
  }
  .seat-gender {
    color: #a8b8ac;
  }
  .seat-effect {
    color: #e0b976;
    white-space: nowrap;
  }
  .seat-you {
    position: absolute;
    top: 48%;
    right: 5px;
    color: #c6d5bb;
  }
  :global(.target-hitbox.unavailable) .seat-status {
    opacity: 0.6;
  }
  @container (max-width: 110px) {
    .seat-status {
      padding: 2px;
      gap: 3px;
      font-size: 10px;
    }
    .seat-name {
      font-size: 17px;
    }
    .health-pips {
      display: none;
    }
    .seat-vitals {
      font-size: 10px;
    }
  }
  @container (max-width: 70px) {
    .seat-status {
      inset: 4px;
      padding: 1px;
      gap: 2px;
    }
    .seat-name {
      font-size: 14px;
    }
  }
  @container (max-height: 64px) {
    .seat-status {
      inset: 3px;
      padding: 1px;
      grid-template-columns: minmax(0, 1fr) auto auto;
      grid-template-rows: 1fr 1fr;
      gap: 1px 4px;
      background: #08181766;
    }
    .seat-name {
      grid-column: 1;
      grid-row: 1;
      font-size: 11px;
      text-align: left;
    }
    .seat-role {
      grid-column: 2;
      grid-row: 1;
      font-size: 10px;
    }
    .seat-hand {
      grid-column: 3;
      grid-row: 1;
      font-size: 10px;
    }
    .seat-vitals {
      grid-column: 1 / -1;
      grid-row: 2;
      justify-content: flex-start;
      flex-wrap: nowrap;
      font-size: 10px;
    }
    .health-pips,
    .full-label {
      display: none;
    }
  }
</style>
