import type { ChoicePreview, GameSelection } from '../../core/view/game';

/** 只补必选且唯一的下一目标；保留多目标的选择顺序，从不自动提交。 */
export function selectForcedTargets(
  draft: GameSelection,
  inspect: (draft: GameSelection) => ChoicePreview,
): GameSelection {
  let next = draft;
  while (true) {
    const preview = inspect(next);
    if (next.targets.length >= preview.targetCount.min) return next;
    const remaining = preview.targets.filter(
      (target) => target.selectable && !next.targets.includes(target.id),
    );
    if (remaining.length !== 1) return next;
    next = { ...next, targets: [...next.targets, remaining[0]!.id] };
  }
}

/** 输入框、组合输入与修饰键不应被全局游戏快捷键截获。 */
export function acceptsGameShortcut(event: KeyboardEvent): boolean {
  if (event.isComposing || event.repeat || event.ctrlKey || event.metaKey || event.altKey)
    return false;
  const target = event.target;
  return !(
    target instanceof Element && target.closest('input, textarea, select, [contenteditable="true"]')
  );
}
