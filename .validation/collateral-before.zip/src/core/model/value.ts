export type DeepReadonly<T> = T extends object
  ? { readonly [K in keyof T]: DeepReadonly<T[K]> }
  : T;

// 只信任本模块创建的完整冻结图；外部 Object.freeze 不能证明子对象不可变。
const snapshots = new WeakSet<object>();

/** 普通数据复制并深冻；既有快照可共享，调用者的可变输入始终与结果隔离。 */
export function immutable<T>(value: T): DeepReadonly<T> {
  const ancestors = new Set<object>();
  const copies = new Map<object, object>();

  function copy(node: unknown): unknown {
    if (node === null || typeof node === 'string' || typeof node === 'boolean') return node;
    if (typeof node === 'number' && Number.isFinite(node)) return node;
    if (typeof node !== 'object' || node === null) throw new Error('Expected plain finite data.');
    if (snapshots.has(node)) return node;
    if (ancestors.has(node)) throw new Error('Cyclic game data.');
    const previous = copies.get(node);
    if (previous) return previous;
    if (!Array.isArray(node) && Object.getPrototypeOf(node) !== Object.prototype)
      throw new Error('Game data must contain only plain objects and arrays.');

    const result: object = Array.isArray(node) ? new Array(node.length) : {};
    copies.set(node, result);
    ancestors.add(node);
    for (const [key, child] of Object.entries(node)) {
      // 数据中的 __proto__ 也是普通自有字段，不能经赋值变成原型修改。
      Object.defineProperty(result, key, {
        value: copy(child),
        enumerable: true,
        configurable: true,
        writable: true,
      });
    }
    ancestors.delete(node);
    Object.freeze(result);
    snapshots.add(result);
    return result;
  }

  return copy(value) as DeepReadonly<T>;
}
