import { resolve } from 'node:path';
import { createGameServer } from './server';
import { createOfflineMatch } from '../app/offline/practice';

const host = process.env.SGS_HOST ?? '127.0.0.1';
const port = Number(process.env.SGS_PORT ?? 1422);
if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error('Invalid SGS_PORT.');
const seed = Number(process.env.SGS_SEED ?? 42);
if (!Number.isSafeInteger(seed) || seed < 1 || seed > 0xffffffff)
  throw new Error('Invalid SGS_SEED.');
const server = createGameServer(
  createOfflineMatch(4, seed, 'standard:identity', [
    'standard:guanyu',
    'standard:caocao',
    'standard:zhangfei',
    'standard:zhaoyun',
  ]),
  { humans: ['甲席', '乙席'], staticRoot: resolve('dist') },
);
const boundPort = await server.listen(port, host);
console.log(`双人联机：http://${host}:${boundPort}/?online=1（其余两席为基础 AI）`);
for (const signal of ['SIGINT', 'SIGTERM'] as const)
  process.once(signal, () => {
    server.close().catch((error: unknown) => {
      console.error(error);
      process.exitCode = 1;
    });
  });
