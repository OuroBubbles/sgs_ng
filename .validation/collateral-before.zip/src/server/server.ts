import { createServer } from 'node:http';
import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { WebSocketServer, WebSocket } from 'ws';
import type { AddressInfo } from 'node:net';
import { NetworkRoom } from '../app/network/room';
import type { ClientMessage } from '../app/network/protocol';
import type { RoleMatch } from '../app/offline/role-match';

/** 一个 HTTP / WebSocket 入口，承载一局对局。 */
export function createGameServer(
  match: RoleMatch,
  options: {
    readonly humans: readonly string[];
    readonly staticRoot?: string;
    readonly aiDelayMs?: number;
  },
) {
  const room = new NetworkRoom(match, options.humans, options.aiDelayMs);
  const root = options.staticRoot ? resolve(options.staticRoot) : null;
  const types: Readonly<Record<string, string>> = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.svg': 'image/svg+xml',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.webp': 'image/webp',
    '.woff2': 'font/woff2',
    '.wasm': 'application/wasm',
  };
  const server = createServer((request, response) => {
    const serve = async () => {
      if (!root || request.method !== 'GET') {
        response.writeHead(404).end();
        return;
      }
      const pathname = decodeURIComponent(new URL(request.url ?? '/', 'http://localhost').pathname);
      const file = resolve(root, pathname === '/' ? 'index.html' : `.${pathname}`);
      if (!file.startsWith(`${root}${sep}`)) {
        response.writeHead(404).end();
        return;
      }
      const info = await stat(file);
      if (!info.isFile()) {
        response.writeHead(404).end();
        return;
      }
      response.writeHead(200, {
        'Content-Type': types[extname(file)] ?? 'application/octet-stream',
        'Content-Length': info.size,
        'Cache-Control': 'no-cache',
      });
      createReadStream(file)
        .on('error', () => response.destroy())
        .pipe(response);
    };
    serve().catch(() => {
      if (!response.headersSent) response.writeHead(404).end();
      else response.destroy();
    });
  });
  const sockets = new WebSocketServer({
    server,
    path: '/game',
    maxPayload: 64 * 1024,
    perMessageDeflate: false,
  });
  sockets.on('connection', (socket) => {
    const joined = room.join((message) => {
      if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(message));
    });
    if (!joined) {
      socket.send(JSON.stringify({ kind: 'error', message: '房间已满或已经开局。' }));
      socket.close(1008);
      return;
    }
    socket.on('error', () => socket.close());
    socket.on('close', () => joined.leave());
    socket.on('message', (data, binary) => {
      try {
        // 私人同版本客户端共享协议；输入选择仍由主持端规则重新验证。
        if (binary) throw new Error('Text messages required.');
        const bytes = Array.isArray(data)
          ? Buffer.concat(data)
          : data instanceof ArrayBuffer
            ? Buffer.from(data)
            : data;
        const message = JSON.parse(bytes.toString('utf8')) as ClientMessage;
        if (!Number.isSafeInteger(message.sequence) || !message.command)
          throw new Error('Invalid message.');
        const result = room.command(joined.seat, message.command);
        socket.send(JSON.stringify({ kind: 'response', sequence: message.sequence, result }));
      } catch {
        socket.send(JSON.stringify({ kind: 'error', message: '消息格式错误。' }));
      }
    });
  });
  return {
    async listen(port = 1422, host = '127.0.0.1'): Promise<number> {
      await new Promise<void>((accept, reject) => {
        server.once('error', reject);
        server.listen(port, host, () => {
          server.off('error', reject);
          accept();
        });
      });
      return (server.address() as AddressInfo).port;
    },
    async close(): Promise<void> {
      room.dispose();
      for (const socket of sockets.clients) socket.terminate();
      await new Promise<void>((accept) => sockets.close(() => accept()));
      await new Promise<void>((accept, reject) =>
        server.close((error) => (error ? reject(error) : accept())),
      );
    },
  };
}
