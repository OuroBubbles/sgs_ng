import type { Context } from '../../core/runtime/room';
import type { Validation } from '../../core/decisions/hub';
import { immutable } from '../../core/model/value';
import { syncQueryValue } from '../../core/runtime/query';
import type { SkillHandle } from './skills';
import type { CardBook } from '../cards/book';
import { isGameOver } from '../game/end';
import type { PhaseView } from '../turn/turn';
import { activePhase, activeTarget } from '../turn/turn';
import { readState } from '../state/state';
import { JointSelection, type JointChoice } from '../../core/decisions/selection';

/** 发动前的牌与目标共用一个选择；提交后的支付、响应与后效仍是普通流程。 */
export interface ActiveSkill {
  readonly id: string;
  readonly label: string;
  readonly available: (
    ctx: Context,
    self: SkillHandle,
    phase: PhaseView,
    book: CardBook,
  ) => boolean;
  /** 纯同步选择工厂；候选与约束在每次预览、提交时读取当前状态。 */
  readonly selection?: (
    ctx: Context,
    self: SkillHandle,
    phase: PhaseView,
    book: CardBook,
  ) => JointSelection;
  readonly run: (
    ctx: Context,
    self: SkillHandle,
    phase: PhaseView,
    book: CardBook,
    choice: JointChoice,
  ) => void | Promise<void>;
}
export interface ActiveChoice extends JointChoice {
  readonly skill: string;
  readonly action: string;
}
export interface ActiveOffer {
  readonly id: string;
  readonly kind: 'active';
  readonly label: string;
  readonly skill: string;
  readonly description: string;
  readonly materials: readonly string[];
  readonly count: { readonly min: number; readonly max: number | 'all' };
  readonly choice: { readonly instance: string; readonly action: string };
}

const emptySelection = new JointSelection({
  cards: () => [],
  targets: () => [],
  cardCount: { min: 0, max: 0 },
  targetCount: { min: 0, max: 0 },
});
const isRecord = (input: unknown): input is Record<string, unknown> =>
  input !== null && typeof input === 'object';

function selection(
  ctx: Context,
  self: SkillHandle,
  phase: PhaseView,
  book: CardBook,
  action: ActiveSkill,
) {
  return action.selection
    ? syncQueryValue(
        action.selection(ctx, self, phase, book),
        `${self.skill}/${action.id}.selection`,
      )
    : emptySelection;
}

function open(ctx: Context, phase: PhaseView): boolean {
  const current = readState(ctx.world, activePhase, activeTarget);
  return (
    current?.id === phase.id &&
    current.stage === 'acting' &&
    phase.kind === 'play' &&
    !phase.skipped &&
    !phase.turn?.ended &&
    phase.lifetime.active &&
    phase.lifetime.belongsTo(ctx.world) &&
    ctx.cause.scopePath.includes(phase.id) &&
    ctx.world.player(phase.owner).alive &&
    !isGameOver(ctx.world)
  );
}

export function validateActive(
  ctx: Context,
  book: CardBook,
  phase: PhaseView,
  input: unknown,
): Validation<ActiveChoice> {
  return ctx.query(() => {
    if (!isRecord(input) || typeof input.skill !== 'string' || typeof input.action !== 'string')
      return { ok: false, reason: 'Expected active skill instance and action.' };
    const binding = book.skills.binding(ctx.world, input.skill);
    const action = binding?.definition.active?.find((action) => action.id === input.action);
    if (
      !(
        open(ctx, phase) &&
        binding &&
        action &&
        binding.self.owner === phase.owner &&
        binding.self.effective(ctx.world) &&
        syncQueryValue(
          action.available(ctx, binding.self, phase, book),
          `${binding.self.skill}/${action.id}.available`,
        )
      )
    )
      return { ok: false, reason: 'Active skill is no longer available.' };
    const checked = selection(ctx, binding.self, phase, book, action).validate(input);
    return checked.ok
      ? { ok: true, value: { skill: input.skill, action: input.action, ...checked.value } }
      : checked;
  });
}

/** 只预览当前实例的选择，不发动、不支付，也不产生额外的决策。 */
export function inspectActive(ctx: Context, book: CardBook, phase: PhaseView, input: unknown) {
  return ctx.query(() => {
    if (!isRecord(input) || typeof input.skill !== 'string' || typeof input.action !== 'string')
      return null;
    const binding = book.skills.binding(ctx.world, input.skill);
    const action = binding?.definition.active?.find((action) => action.id === input.action);
    if (
      !open(ctx, phase) ||
      !binding ||
      !action ||
      binding.self.owner !== phase.owner ||
      !binding.self.effective(ctx.world) ||
      !syncQueryValue(
        action.available(ctx, binding.self, phase, book),
        `${binding.self.skill}/${action.id}.available`,
      )
    )
      return null;
    const model = selection(ctx, binding.self, phase, book, action);
    return { ...model.describe(), ...model.inspect(input), fixedTargets: [] };
  });
}

export function activeOffers(
  ctx: Context,
  book: CardBook,
  phase: PhaseView,
): readonly ActiveOffer[] {
  return ctx.query(() => {
    if (!open(ctx, phase)) return [];
    return immutable(
      book.skills.bindings(ctx.world).flatMap(({ self, definition }) => {
        if (self.owner !== phase.owner || !self.effective(ctx.world)) return [];
        return (definition.active ?? [])
          .filter((action) =>
            syncQueryValue(
              action.available(ctx, self, phase, book),
              `${self.skill}/${action.id}.available`,
            ),
          )
          .map((action): ActiveOffer => {
            const described = selection(ctx, self, phase, book, action).describe();
            return {
              id: JSON.stringify(['active', self.id, action.id]),
              kind: 'active',
              label: action.label,
              skill: self.skill,
              description: definition.description ?? '',
              materials: described.preview.cards.map((card) => card.id),
              count: described.cardCount,
              choice: { instance: self.id, action: action.id },
            };
          });
      }),
    );
  });
}

/** 执行前重查实例、所属席位和阶段；后续费用与宣告由普通技能代码明确提交。 */
export function activate(
  ctx: Context,
  book: CardBook,
  phase: PhaseView,
  input: ActiveChoice,
): Promise<void> {
  const choice = immutable(input);
  return ctx.flow('skill.active', async (child) => {
    const checked = validateActive(child, book, phase, choice);
    if (!checked.ok) return;
    const { self, definition } = book.skills.binding(child.world, choice.skill)!;
    await definition
      .active!.find((action) => action.id === choice.action)!
      .run(child, self, phase, book, checked.value);
  });
}
