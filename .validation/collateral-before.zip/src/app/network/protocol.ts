import type { ReplyResult } from '../../core/decisions/hub';
import type { ChoicePreview, GameSelection, GameView } from '../../core/view/game';

/** 传输普通数据，绝不传递规则闭包、World 或原始决策描述。 */
export type ClientCommand =
  | { readonly kind: 'ready' }
  | { readonly kind: 'delegate'; readonly enabled: boolean }
  | {
      readonly kind: 'inspect';
      readonly id: string;
      readonly token: number;
      readonly selection: GameSelection;
    }
  | {
      readonly kind: 'inspect-answer';
      readonly id: string;
      readonly token: number;
      readonly value: unknown;
    }
  | {
      readonly kind: 'reply';
      readonly id: string;
      readonly token: number;
      readonly selection: GameSelection;
    }
  | {
      readonly kind: 'answer';
      readonly id: string;
      readonly token: number;
      readonly value: unknown;
    }
  | { readonly kind: 'cancel'; readonly id: string; readonly token: number };

export interface ClientMessage {
  readonly sequence: number;
  readonly command: ClientCommand;
}

export interface LobbyView {
  readonly seat: string;
  readonly waitingFor: string | null;
  readonly seats: readonly {
    readonly id: string;
    readonly connected: boolean;
    readonly ready: boolean;
  }[];
}

export type CommandResult =
  | ReplyResult
  | ChoicePreview
  | { readonly valid: boolean; readonly reason: string };
export type ServerMessage =
  | { readonly kind: 'view'; readonly lobby: LobbyView; readonly view: GameView }
  | { readonly kind: 'response'; readonly sequence: number; readonly result: CommandResult }
  | { readonly kind: 'error'; readonly message: string };

export const closedReply = (message: string): ReplyResult => ({
  kind: 'rejected',
  reason: 'closed',
  message,
});
