import type { ReplyResult } from '../../core/decisions/hub';
import type { ChoicePreview, GameSelection, GameView } from '../../core/view/game';
import { emptyPreview } from '../../core/view/game';
import { closedReply } from './protocol';
import type { ClientCommand, CommandResult, LobbyView, ServerMessage } from './protocol';

/** 地址只决定主持端位置；客户端保留自己的页面，协议仍固定为 /game。 */
function socketAddress(address: string): string {
  try {
    const input = address.trim();
    if (!input) throw new Error();
    const url = new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(input) ? input : `http://${input}`);
    if (!['http:', 'https:', 'ws:', 'wss:'].includes(url.protocol) || url.username || url.password)
      throw new Error();
    url.protocol = url.protocol === 'https:' || url.protocol === 'wss:' ? 'wss:' : 'ws:';
    url.pathname = '/game';
    url.search = '';
    url.hash = '';
    return url.href;
  } catch {
    throw new Error('主持端地址无效，请填写主机与端口。');
  }
}

/** 远端展示适配。预览缓存只保存主持端结果，绝不在客户端重算规则。 */
export class RemoteSession {
  readonly #socket: WebSocket;
  readonly #listeners = new Set<(view: GameView) => void>();
  readonly #pending = new Map<number, (result: CommandResult) => void>();
  readonly #previews = new Map<string, CommandResult | null>();
  #sequence = 0;
  #view: GameView;
  #latest: GameView;
  #lobby: LobbyView | null = null;
  #paused = false;
  #closed = false;
  #generation = '';

  constructor(address: string, initial: GameView) {
    this.#view = this.#latest = initial;
    this.#socket = new WebSocket(socketAddress(address));
    this.#socket.addEventListener('message', (event: MessageEvent<string>) => {
      const message = JSON.parse(event.data) as ServerMessage;
      if (message.kind === 'view') {
        this.#latest = message.view;
        this.#lobby = message.lobby;
        const generation = `${message.view.revision}:${message.view.decision?.id}:${message.view.decision?.token}`;
        if (generation !== this.#generation) {
          this.#generation = generation;
          this.#previews.clear();
        }
        this.#publish();
      } else if (message.kind === 'response') {
        const resolve = this.#pending.get(message.sequence);
        this.#pending.delete(message.sequence);
        resolve?.(message.result);
      } else this.#fail(message.message);
    });
    this.#socket.addEventListener('close', () => this.#fail('与主持端的连接已断开。'));
    this.#socket.addEventListener('error', () => this.#fail('无法连接主持端。'));
  }
  get human(): string | null {
    return this.#lobby?.seat ?? null;
  }
  get lobby(): LobbyView | null {
    return this.#lobby;
  }
  get view(): GameView {
    return this.#view;
  }
  subscribe(listener: (view: GameView) => void): () => void {
    this.#listeners.add(listener);
    listener(this.#view);
    return () => {
      this.#listeners.delete(listener);
    };
  }
  start(): void {
    this.#request({ kind: 'ready' })
      .then((result) => {
        if ('kind' in result && result.kind === 'rejected') this.#fail(result.message);
      })
      .catch((error: unknown) => this.#fail(String(error)));
  }
  dispose(): void {
    this.#closed = true;
    this.#settlePending();
    this.#listeners.clear();
    this.#socket.close();
  }
  hide(): void {
    this.#paused = true;
    this.#publish();
  }
  resume(): void {
    this.#paused = false;
    this.#publish();
  }
  confirmSeat(): void {
    /* 远端席位由连接分配，无热坐交接。 */
  }

  inspect(
    id: string | undefined,
    token: number | undefined,
    selection: GameSelection,
  ): ChoicePreview {
    if (!id || token === undefined || this.#paused || this.#closed) return emptyPreview();
    const result = this.#preview({ kind: 'inspect', id, token, selection });
    return result && 'targetCount' in result ? result : emptyPreview('正在核对选择…');
  }
  inspectAnswer(
    id: string,
    token: number,
    value: unknown,
  ): { readonly valid: boolean; readonly reason: string } {
    if (this.#paused || this.#closed) return { valid: false, reason: '当前不可操作' };
    const result = this.#preview({ kind: 'inspect-answer', id, token, value });
    return result && 'valid' in result ? result : { valid: false, reason: '正在核对选择…' };
  }
  async reply(id: string, token: number, selection: GameSelection): Promise<ReplyResult> {
    return this.#reply({ kind: 'reply', id, token, selection });
  }
  async answer(id: string, token: number, value: unknown): Promise<ReplyResult> {
    return this.#reply({ kind: 'answer', id, token, value });
  }
  async cancel(id: string, token: number): Promise<ReplyResult> {
    return this.#reply({ kind: 'cancel', id, token });
  }
  async setDelegated(enabled: boolean): Promise<ReplyResult> {
    return this.#reply({ kind: 'delegate', enabled });
  }
  async #reply(command: ClientCommand): Promise<ReplyResult> {
    if (this.#paused && command.kind !== 'delegate') return closedReply('请先恢复显示。');
    const result = await this.#request(command);
    return 'kind' in result ? result : closedReply('主持端返回了错误的响应。');
  }
  #preview(command: ClientCommand): CommandResult | null {
    const key = JSON.stringify(command);
    if (!this.#previews.has(key)) {
      this.#previews.set(key, null);
      const generation = this.#generation;
      this.#request(command)
        .then((result) => {
          // 迟到响应不覆盖新决策或不同状态的预览。
          if (this.#closed || generation !== this.#generation) return;
          this.#previews.set(key, result);
          this.#publish();
        })
        .catch((error: unknown) => this.#fail(String(error)));
    }
    return this.#previews.get(key) ?? null;
  }
  #request(command: ClientCommand): Promise<CommandResult> {
    if (this.#closed || this.#socket.readyState !== WebSocket.OPEN)
      return Promise.resolve(closedReply('尚未连接或连接已关闭。'));
    const sequence = ++this.#sequence;
    return new Promise((resolve) => {
      this.#pending.set(sequence, resolve);
      // Svelte 草稿可能为 Proxy；JSON 是实际传输边界。
      this.#socket.send(JSON.stringify({ sequence, command }));
    });
  }
  #settlePending(): void {
    for (const resolve of this.#pending.values()) resolve(closedReply('连接已关闭。'));
    this.#pending.clear();
    this.#previews.clear();
  }
  #fail(message: string): void {
    if (this.#closed) return;
    this.#closed = true;
    this.#settlePending();
    this.#latest = { ...this.#latest, status: 'stopped', error: message, decision: null };
    this.#paused = false;
    this.#publish();
    this.#socket.close();
  }
  #publish(): void {
    this.#view = this.#paused
      ? {
          ...this.#latest,
          viewer: null,
          hand: [],
          decision: null,
          paused: true,
          pools: this.#latest.pools.filter((pool) => pool.visibility !== 'private'),
          players: this.#latest.players.map((player) => ({
            ...player,
            role: player.self ? null : player.role,
          })),
        }
      : { ...this.#latest };
    for (const listener of this.#listeners) listener(this.#view);
  }
}
