import type { DecisionRequest } from '../../core/decisions/hub';
import { immutable } from '../../core/model/value';
import { projectMatch } from '../offline/projection';
import { emptyPreview } from '../../core/view/game';
import { inspectSelection, selectionInput } from '../offline/selection';
import type { RoleMatch } from '../offline/role-match';
import { AgentDriver } from '../offline/agent-driver';
import { closedReply } from './protocol';
import type { ClientCommand, CommandResult, ServerMessage } from './protocol';

/** 一局的唯一主持者。连接只获得分配的席位，所有选择在此落到原有规则。 */
export class NetworkRoom {
  readonly #clients = new Map<string, (message: ServerMessage) => void>();
  readonly #ready = new Set<string>();
  readonly #unsubscribe: () => void;
  #started = false;
  #closed = false;
  #error = '';
  #publication: ReturnType<typeof setTimeout> | null = null;
  readonly #agent: AgentDriver;
  readonly #delegated = new Set<string>();
  readonly #controlReasons = new Map<string, string>();

  constructor(
    private readonly match: RoleMatch,
    private readonly humans: readonly string[],
    aiDelayMs = 300,
  ) {
    if (
      !humans.length ||
      new Set(humans).size !== humans.length ||
      humans.some((id) => !match.initial.players.some((player) => player.id === id))
    )
      throw new Error('Invalid human seats.');
    this.#agent = new AgentDriver(match, aiDelayMs, (update) => {
      if (update.kind === 'unsupported' && this.#delegated.has(update.player)) {
        this.#delegated.delete(update.player);
        this.#controlReasons.set(update.player, update.reason);
      } else if (update.kind !== 'changed') {
        this.#stop(update.reason);
      }
      this.#changed();
    });
    this.#unsubscribe = match.room.history.subscribe(() => this.#changed());
  }

  /** 空位只在开局前分配；断线续局不通过重建事实冒充恢复协程。 */
  join(
    send: (message: ServerMessage) => void,
  ): { readonly seat: string; readonly leave: () => void } | null {
    if (this.#closed || this.#started) return null;
    const seat = this.humans.find((id) => !this.#clients.has(id));
    if (!seat) return null;
    this.#clients.set(seat, send);
    this.#changed();
    return {
      seat,
      leave: () => {
        if (this.#clients.get(seat) !== send) return;
        this.#clients.delete(seat);
        this.#ready.delete(seat);
        if (this.#started && !this.match.result) this.#stop(`${seat} 已断开，本局结束。`);
        this.#changed();
      },
    };
  }

  command(seat: string, command: ClientCommand): CommandResult {
    try {
      return this.#command(seat, command);
    } catch (error) {
      // 合法消息也可能触发作者校验故障；保留规则错误，统一结束该局。
      const reason = error instanceof Error ? error.message : String(error);
      this.#stop(reason);
      return closedReply(reason);
    }
  }

  #command(seat: string, command: ClientCommand): CommandResult {
    if (this.#closed || !this.#clients.has(seat)) return closedReply('连接已关闭。');
    if (command.kind === 'ready') {
      if (this.#started) return closedReply('牌局已经开始。');
      this.#ready.add(seat);
      if (this.humans.every((id) => this.#clients.has(id) && this.#ready.has(id))) {
        this.#started = true;
        this.match
          .start()
          .then((result) => {
            if (result.kind === 'aborted' && !this.#closed) this.#error ||= result.reason;
            this.#changed();
          })
          .catch((error: unknown) =>
            this.#stop(error instanceof Error ? error.message : String(error)),
          );
      }
      this.#changed();
      return { kind: 'accepted' };
    }
    if (command.kind === 'delegate') {
      if (!this.#started || this.#error || this.match.result)
        return closedReply('当前不能切换控制权。');
      if (command.enabled) this.#delegated.add(seat);
      else this.#delegated.delete(seat);
      this.#controlReasons.delete(seat);
      // 先撤销旧定时任务，再广播与安排新控制者，避免窗口内迟到的 AI 答案。
      this.#agent.update(null);
      this.#changed();
      return { kind: 'accepted' };
    }
    const request = this.#authorized(seat, command.id, command.token);
    if (!request) {
      return command.kind === 'inspect'
        ? emptyPreview('选择已结束或不属于此席位')
        : command.kind === 'inspect-answer'
          ? { valid: false, reason: '选择已结束或不属于此席位' }
          : closedReply('选择已结束或不属于此席位。');
    }
    const hub = this.match.room.decisions;
    switch (command.kind) {
      case 'inspect':
        return inspectSelection(this.match, request, command.selection);
      case 'inspect-answer': {
        const preview = hub.preview(command.id, command.value);
        return { valid: preview?.valid ?? false, reason: preview?.reason ?? '选择已结束' };
      }
      case 'reply':
      case 'answer':
      case 'cancel': {
        const result =
          command.kind === 'cancel'
            ? hub.cancel(command.id, command.token)
            : hub.submit(
                command.id,
                command.token,
                command.kind === 'reply'
                  ? selectionInput(request, command.selection)
                  : command.value,
              );
        if (result.kind === 'accepted') this.#controlReasons.delete(seat);
        return result;
      }
    }
  }

  dispose(): void {
    if (this.#closed) return;
    this.#closed = true;
    this.#agent.update(null);
    if (this.#publication) clearTimeout(this.#publication);
    this.#publication = null;
    this.#unsubscribe();
    this.#clients.clear();
    this.match.room.abort('Network room closed.');
  }

  #authorized(seat: string, id: string, token: number): DecisionRequest | null {
    if (this.#error || this.#delegated.has(seat)) return null;
    return (
      this.match.room.decisions.pending.find(
        (request) =>
          request.id === id &&
          request.token === token &&
          request.player === seat &&
          request.kind !== 'seat-ready',
      ) ?? null
    );
  }
  #stop(reason: string): void {
    if (this.#closed) return;
    this.#error = reason;
    this.#agent.update(null);
    this.match.room.abort(reason);
    this.#changed();
  }
  #changed(): void {
    if (this.#closed || this.#publication) return;
    // 普通 await 会继续拆分微任务；在本次事件循环后再投影整段结算。
    this.#publication = setTimeout(() => {
      this.#publication = null;
      if (this.#closed) return;
      const request = this.match.room.decisions.pending[0] ?? null;
      const automated =
        request &&
        (request.kind === 'seat-ready' ||
          !this.humans.includes(request.player) ||
          this.#delegated.has(request.player));
      for (const [seat, send] of this.#clients) {
        send({
          kind: 'view',
          lobby: {
            seat,
            waitingFor: request && !automated ? request.player : null,
            seats: this.humans.map((id) => ({
              id,
              connected: this.#clients.has(id),
              ready: this.#ready.has(id),
            })),
          },
          view: immutable({
            ...projectMatch(
              this.match,
              seat,
              request?.player === seat &&
                !this.#delegated.has(seat) &&
                request.kind !== 'seat-ready'
                ? request
                : null,
              this.#error,
              seat,
            ),
            automated: automated ? request.player : null,
            control: {
              delegated: this.#delegated.has(seat),
              reason: this.#controlReasons.get(seat) ?? '',
            },
          }),
        });
      }
      this.#agent.update(automated && !this.#error && !this.match.result ? request : null);
    }, 0);
  }
}
