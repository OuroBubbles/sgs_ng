import * as sdk from '../../sdk';
import { definePackage, resolvePackages } from '../../content/package';
import type { ContentPackage } from '../../content/package';
import { contentAssets, leaseContentAssets } from './content-assets';
import type { ContentAsset } from './content-assets';

export interface ContentFile {
  readonly name: string;
  text(): Promise<string>;
  arrayBuffer?(): Promise<ArrayBuffer>;
  /** 恢复时直接使用已保存的二进制，不依赖原始文件。 */
  readonly assets?: readonly ContentAsset[];
}

export interface LoadedContentModule {
  readonly fileName: string;
  readonly source: string;
  readonly package: ContentPackage;
  readonly assets?: readonly ContentAsset[];
  readonly dispose?: () => void;
  /** 一次加载的真实导出命名空间；不克隆、不持久保存。 */
  readonly exports?: Readonly<Record<string, unknown>>;
}

function compiledModule(module: unknown) {
  if (
    !module ||
    typeof module !== 'object' ||
    !('format' in module) ||
    module.format !== 'sgs-content/1' ||
    !('default' in module) ||
    typeof module.default !== 'function'
  )
    throw new Error('请选择由 content:build 生成的 .sgs.mjs 内容模块。');
  const imports: unknown = 'imports' in module ? module.imports : [];
  if (
    !Array.isArray(imports) ||
    imports.some((id: unknown) => typeof id !== 'string' || !/^[a-z][a-z0-9_-]*$/.test(id)) ||
    new Set(imports).size !== imports.length
  )
    throw new Error('内容模块代码依赖声明不正确。');
  if ('createNamespace' in module && typeof module.createNamespace !== 'function')
    throw new Error('内容模块导出工厂不正确。');
  if (imports.length && !('createNamespace' in module))
    throw new Error('内容模块代码依赖需要导出工厂。');
  return { module, imports: imports as string[] };
}

/** 执行一次可信普通代码。宿主与依赖都使用真实对象，不按名称重建 Window/Query。 */
export function instantiateContentModule(
  module: unknown,
  assets = leaseContentAssets([]),
  providers: readonly LoadedContentModule[] = [],
): Pick<LoadedContentModule, 'package' | 'exports'> {
  const compiled = compiledModule(module);
  const dependencies = Object.fromEntries(
    compiled.imports.map((id) => {
      const provider = providers.find((entry) => entry.package.manifest.id === id);
      if (!provider) throw new Error(`缺少代码依赖：${id}`);
      return [id, provider.exports ?? { default: provider.package }];
    }),
  );
  const create = (
    'createNamespace' in compiled.module ? compiled.module.createNamespace : compiled.module.default
  ) as (
    host: typeof sdk,
    resources: Pick<typeof assets, 'url'>,
    dependencies: Readonly<Record<string, Readonly<Record<string, unknown>>>>,
  ) => unknown;
  const result = create(sdk, assets, dependencies);
  const namespace = 'createNamespace' in compiled.module ? result : { default: result };
  const input =
    namespace && typeof namespace === 'object' && 'default' in namespace
      ? namespace.default
      : undefined;
  if (
    !input ||
    typeof input !== 'object' ||
    !('manifest' in input) ||
    !input.manifest ||
    typeof input.manifest !== 'object'
  )
    throw new Error('内容模块必须同步返回一个 definePackage 声明。');
  const pack = definePackage(input as ContentPackage);
  for (const id of compiled.imports) {
    const required = pack.manifest.requires?.find((entry) => entry.id === id);
    if (!required)
      throw new Error(`[${pack.manifest.id}] 代码依赖必须声明 manifest.requires：${id}`);
    const actual = providers.find((entry) => entry.package.manifest.id === id)!.package.manifest
      .version;
    if (required.version !== undefined && required.version !== actual)
      throw new Error(
        `[${pack.manifest.id}] 代码依赖版本不符：${id}，需要 ${required.version}，实际 ${actual}`,
      );
  }
  return { package: pack, exports: namespace as Readonly<Record<string, unknown>> };
}

/** 单个无代码依赖的模块也可直接实例化；不创建/修改正在运行的 Room。 */
export function contentFromModule(
  module: unknown,
  assets = leaseContentAssets([]),
): ContentPackage {
  return instantiateContentModule(module, assets).package;
}

/** 一批文件全部解析/装配成功后才交付新目录；重复 ID 不覆盖现有包。 */
export function stageContentModules(
  current: readonly ContentPackage[],
  incoming: readonly ContentPackage[],
): readonly ContentPackage[] {
  const next = Object.freeze([...current, ...incoming]);
  const resolved = resolvePackages(
    next,
    next.map((entry) => entry.manifest.id),
  );
  resolved.createBooks();
  for (const deck of resolved.decks) resolved.createDeck(deck.id);
  return next;
}

export async function readContentModules(
  files: readonly ContentFile[],
  current: readonly LoadedContentModule[] = [],
): Promise<readonly LoadedContentModule[]> {
  const settled = await Promise.allSettled(
    files.map(async (file) => {
      let lease: ReturnType<typeof leaseContentAssets> | undefined;
      let url: string | undefined;
      try {
        const loaded =
          file.assets !== undefined
            ? { source: await file.text(), assets: contentAssets(file.assets) }
            : file.name.endsWith('.sgs')
              ? await (async () => {
                  if (!file.arrayBuffer) throw new Error('请选择完整的二进制 .sgs 内容包。');
                  const { readContentBundle } = await import('./content-bundle');
                  return readContentBundle(await file.arrayBuffer());
                })()
              : { source: await file.text(), assets: [] };
        const { source, assets } = loaded;
        lease = leaseContentAssets(assets);
        url = URL.createObjectURL(new Blob([source], { type: 'text/javascript' }));
        const module: unknown = await import(/* @vite-ignore */ url);
        const compiled = compiledModule(module);
        return {
          fileName: file.name,
          source,
          assets,
          compiled,
          lease,
          dispose: lease.dispose,
        };
      } catch (error) {
        lease?.dispose();
        throw new Error(`${file.name}：${error instanceof Error ? error.message : String(error)}`, {
          cause: error,
        });
      } finally {
        if (url) URL.revokeObjectURL(url);
      }
    }),
  );
  const error = settled.find((entry) => entry.status === 'rejected');
  if (error) {
    for (const entry of settled) if (entry.status === 'fulfilled') entry.value.dispose();
    throw error.reason instanceof Error ? error.reason : new Error(String(error.reason));
  }
  const prepared = settled.flatMap((entry) => (entry.status === 'fulfilled' ? [entry.value] : []));
  const waiting = new Set(prepared);
  const providers = [...current];
  const loaded = new Map<(typeof prepared)[number], LoadedContentModule>();
  try {
    while (waiting.size) {
      const size = waiting.size;
      for (const entry of waiting) {
        if (
          !entry.compiled.imports.every((id) =>
            providers.some((provider) => provider.package.manifest.id === id),
          )
        )
          continue;
        try {
          const instance = instantiateContentModule(entry.compiled.module, entry.lease, providers);
          const id = instance.package.manifest.id;
          if (providers.some((provider) => provider.package.manifest.id === id))
            throw new Error(`Duplicate package: ${id}`);
          const value = Object.freeze({
            fileName: entry.fileName,
            source: entry.source,
            assets: entry.assets,
            dispose: entry.dispose,
            ...instance,
          });
          loaded.set(entry, value);
          providers.push(value);
          waiting.delete(entry);
        } catch (error) {
          throw new Error(
            `${entry.fileName}：${error instanceof Error ? error.message : String(error)}`,
            { cause: error },
          );
        }
      }
      if (size === waiting.size)
        throw new Error(
          `代码依赖缺失或循环：${[...waiting].map((entry) => `${entry.fileName} → ${entry.compiled.imports.filter((id) => !providers.some((provider) => provider.package.manifest.id === id)).join(', ')}`).join('；')}`,
        );
    }
    // 保持输入顺序供持久记录核对；执行顺序只由代码依赖决定。
    return Object.freeze(prepared.map((entry) => loaded.get(entry)!));
  } catch (error) {
    for (const entry of prepared) entry.dispose();
    throw error;
  }
}

/** 停用/移除一个包时连同依赖它的显式选择一起移除，避免“未勾选却仍启用”。 */
export function dependentPackages(
  packages: readonly ContentPackage[],
  id: string,
): readonly string[] {
  return packages
    .filter((entry) =>
      resolvePackages(packages, [entry.manifest.id]).versions.some((version) => version.id === id),
    )
    .map((entry) => entry.manifest.id);
}
