import { spawn, type ChildProcess } from 'node:child_process';
import { once } from 'node:events';
import { test, expect } from '@playwright/test';

let host: ChildProcess;
let url = '';
test.beforeAll(async () => {
  host = spawn(process.execPath, ['.artifacts/server/main.mjs'], {
    cwd: process.cwd(),
    env: { ...process.env, SGS_HOST: '127.0.0.1', SGS_PORT: '0', SGS_SEED: '2' },
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });
  url = await new Promise<string>((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error('Host did not start.')), 10_000);
    let output = '';
    host.stdout!.on('data', (data: Buffer) => {
      output += data.toString();
      const found = output.match(/http:\/\/127\.0\.0\.1:\d+\/\?online=1/);
      if (found) {
        clearTimeout(timeout);
        resolve(found[0]);
      }
    });
    host.once('error', reject);
    host.once('exit', (code) => {
      clearTimeout(timeout);
      reject(new Error(`Host exited: ${code}`));
    });
  });
});
test.afterAll(async () => {
  if (host && host.exitCode === null) {
    const ended = once(host, 'exit');
    host.kill();
    await ended;
  }
});

test('两个独立牌桌入席、托管交接、远端预览、藏牌和断线结束', async ({ page, browser }, info) => {
  test.setTimeout(60_000);
  const context = await browser.newContext({
    viewport: page.viewportSize(),
    isMobile: info.project.use.isMobile ?? false,
    hasTouch: info.project.use.hasTouch ?? false,
    deviceScaleFactor: info.project.use.deviceScaleFactor ?? 1,
    ...(info.project.use.userAgent ? { userAgent: info.project.use.userAgent } : {}),
  });
  const other = await context.newPage();
  const errors: string[] = [];
  for (const client of [page, other]) {
    client.on('pageerror', (error) => errors.push(error.message));
    client.on('console', (message) => {
      if (message.type() === 'error') errors.push(message.text());
    });
  }
  try {
    // 客户端保留自己的来源，并使用实际原生 CSP 跨来源连接主持端。
    await page.goto('/');
    await page.getByRole('spinbutton').fill('0');
    await page.getByText('加入联机', { exact: true }).click();
    await page.getByRole('textbox', { name: '主持端地址' }).fill('ftp://127.0.0.1');
    await page.getByRole('button', { name: '连接主持端' }).click();
    await expect(page.getByRole('alert')).toContainText('主持端地址无效');
    await expect(page.getByRole('button', { name: '开始单机对局' })).toBeEnabled();
    await page.getByRole('textbox', { name: '主持端地址' }).fill(url);
    await page.getByRole('button', { name: '连接主持端' }).click();
    await expect(page.locator('.room-tag')).toHaveText('联机 · 甲席');
    await other.goto(url);
    await expect(other.locator('.room-tag')).toHaveText('联机 · 乙席');
    for (const client of [page, other])
      await expect(client.getByTestId('battle-canvas').locator('canvas')).toBeVisible();
    await page.getByRole('button', { name: '准备对局' }).click();
    await expect(page.getByRole('button', { name: '准备对局' })).toBeDisabled();
    await expect(other.getByText('甲席 · 已准备')).toBeVisible();
    await other.getByRole('button', { name: '准备对局' }).click();
    // 种子 2 让甲席先手；原种子 42 的 AI 先手整局由网络场景验证。
    await expect
      .poll(
        async () =>
          (await page.locator('[data-decision-kind="play-action"]').count()) +
          (await other.locator('[data-decision-kind="play-action"]').count()),
      )
      .toBe(1);
    const actor = (await page.locator('[data-decision-kind="play-action"]').count()) ? page : other;
    const waiting = actor === page ? other : page;
    await actor.getByRole('button', { name: 'AI 托管', exact: true }).click();
    await expect(actor.getByRole('button', { name: '收回操作', exact: true })).toHaveAttribute(
      'aria-pressed',
      'true',
    );
    await actor.getByRole('button', { name: '收回操作', exact: true }).click();
    await expect(actor.getByRole('button', { name: 'AI 托管', exact: true })).toHaveAttribute(
      'aria-pressed',
      'false',
    );
    await expect(actor.locator('[data-decision-kind="play-action"]')).toBeVisible();
    await expect(waiting.locator('[data-decision-kind]')).toHaveAttribute('data-decision-kind', '');
    await expect(waiting.locator('.decision-actions button')).toHaveCount(0);
    await expect(waiting.getByTestId('decision-hint')).toHaveText(/等待 .+ 选择/);
    await expect(actor.locator('.target-hitbox.self')).toHaveAttribute(
      'data-testid',
      actor === page ? 'target-甲席' : 'target-乙席',
    );
    const hand = actor.getByTestId('hand-cards').getByRole('button');
    const count = await hand.count();
    expect(count).toBeGreaterThan(0);
    await actor.getByRole('button', { name: '隐藏联机手牌', exact: true }).click();
    await expect(hand).toHaveCount(0);
    await actor.getByRole('button', { name: '恢复手牌', exact: true }).click();
    await expect(hand).toHaveCount(count);
    // 确认至少一张真实手牌经主持端预览变为合法；目标也来自远端反馈。
    const confirm = actor.getByRole('button', { name: '确认当前选择', exact: true });
    let chosen = false;
    let chosenCard = '';
    for (let index = 0; index < count; index++) {
      chosenCard = (await hand.nth(index).getAttribute('data-testid'))!;
      await hand.nth(index).click();
      await expect(actor.locator('.decision-copy small')).not.toContainText('正在核对');
      if (await confirm.isEnabled()) {
        chosen = true;
        break;
      }
      const targets = actor.locator('.target-hitbox[aria-disabled="false"]');
      if (await targets.count()) {
        await targets.first().click();
        await expect(actor.locator('.decision-copy small')).not.toContainText('正在核对');
        if (await confirm.isEnabled()) {
          chosen = true;
          break;
        }
      }
    }
    expect(chosen).toBe(true);
    await confirm.click();
    await expect(actor.getByTestId('hand-cards').getByTestId(chosenCard)).toHaveCount(0);
    await expect(actor.getByTestId('journal')).not.toBeEmpty();
    await page.screenshot({ path: `.artifacts/ui/network-${info.project.name}-甲.png` });
    await other.screenshot({ path: `.artifacts/ui/network-${info.project.name}-乙.png` });
    await other.close();
    await expect(page.getByRole('region', { name: '对局中止' })).toContainText('乙席 已断开');
    await page.getByRole('button', { name: '返回单机' }).click();
    await expect(page.getByRole('button', { name: '开始单机对局' })).toBeVisible();
    await expect(page.getByRole('spinbutton')).toHaveValue('0');
    expect(page.url()).toBe('http://127.0.0.1:1420/');
    expect(errors).toEqual([]);
  } finally {
    await context.close();
  }
});
