import { expect, it } from 'vitest';
import {
  equip,
  installCounterspells,
  kill,
  moveCards,
  useDeclared,
  withLifetime,
} from '../../src/sdk';
import type { CardOffer, UseIntent } from '../../src/sdk';
import { wusheng } from '../../src/content/standard/wusheng';
import { card, cardGame, use } from '../fixtures/cards';
import { nextRequest } from '../fixtures/room';
import { rebuildWorld } from '../../src/core/history/rebuild';

type Game = ReturnType<typeof cardGame>;
const intent = (parameters: unknown = { victim: 'c' }): UseIntent => ({
  actor: 'a',
  choice: { kind: 'physical', card: 'borrow' },
  targets: ['b'],
  timing: { kind: 'effect' },
  parameters,
});
function create(slashes = 0) {
  return cardGame({
    hands: {
      a: [card('borrow', 'collateral')],
      b: Array.from({ length: slashes }, (_, i) => card(`s${i}`, 'slash')),
    },
    equipment: { b: [card('weapon', 'crossbow')] },
  });
}
async function answer(game: Game, value: unknown, kind = 'use-card') {
  const request = await nextRequest(game.room);
  expect(request.kind).toBe(kind);
  expect(game.room.decisions.submit(request.id, request.token, value).kind).toBe('accepted');
}
function killPlayer(game: Game, target: string) {
  game.room.on(useDeclared, {
    id: `kill-${target}`,
    owner: null,
    eligible: (_ctx, use) => use.card.name === 'standard:collateral',
    async run(ctx) {
      await kill(ctx, {
        player: target,
        killer: null,
        reason: 'rule',
        cause: { kind: 'rule', seq: null, data: null },
      });
    },
  });
}

it('附属选择先于宣告；锦囊只以持武器者为目标，随后完整使用杀', async () => {
  const game = create(1);
  const running = use(game, { ...intent(), parameters: undefined });
  const request = await nextRequest(game.room);
  expect(request).toMatchObject({
    player: 'a',
    kind: 'cards-targets',
    data: { cancelLabel: '取消用牌' },
  });
  expect(game.room.world.position('borrow')).toBe('a:hand');
  expect(game.room.history.facts('card.used')).toHaveLength(0);
  await answer(game, { cards: [], targets: ['c'] }, 'cards-targets');
  const useRequest = await nextRequest(game.room);
  expect(useRequest).toMatchObject({
    player: 'b',
    kind: 'use-card',
    data: { targets: ['c'], timing: 'effect' },
  });
  expect(game.room.history.facts('card.used')).toHaveLength(1);
  await answer(game, { kind: 'physical', card: 's0' });
  const result = await running;
  expect(result).toMatchObject({
    value: { use: { parameters: { victim: 'c' }, effects: [{ target: 'b' }] } },
  });
  expect(game.room.world.player('c').hp).toBe(3);
  expect(game.room.world.position('weapon')).toBe('b:equipment');
  expect(game.room.history.facts('card.used')).toHaveLength(2);
  expect(game.room.history.facts('card.responded')).toHaveLength(0);
  expect(rebuildWorld(game.initial, game.room.history.facts())).toEqual(game.room.world.snapshot);
});

it('取消附属选择不支付、不开放反制，且没有遗留处理区', async () => {
  const game = create();
  const running = use(game, { ...intent(), parameters: undefined });
  const request = await nextRequest(game.room);
  expect(game.room.decisions.cancel(request.id, request.token).kind).toBe('accepted');
  expect(await running).toMatchObject({ value: { kind: 'unavailable' } });
  expect(game.room.world.position('borrow')).toBe('a:hand');
  expect(game.room.history.facts('card.used')).toHaveLength(0);
  expect(game.room.world.snapshot.zones.some((zone) => zone.kind === 'processing')).toBe(false);
});

it('没有杀自动获得武器；选择拒绝用杀时同样获得，装备能力随实体离场', async () => {
  for (const count of [0, 1]) {
    const game = create(count);
    const running = use(game, intent());
    if (count) {
      const request = await nextRequest(game.room);
      game.room.decisions.cancel(request.id, request.token);
    }
    await running;
    expect(game.room.world.position('weapon')).toBe('a:hand');
    expect(game.room.history.facts('collateral.weapon-taken')).toHaveLength(1);
    expect(
      game.skills.bindings(game.room.world).some(({ self }) => self.origin?.id === 'weapon'),
    ).toBe(false);
    expect(game.room.world.player('c').hp).toBe(4);
  }
});

it.each([null, {}, { victim: 'b' }, { victim: 'd' }, { victim: 'unknown' }])(
  '附属目标无效时不宣告、不支付：%j',
  async (parameters) => {
    const game = create();
    expect(await use(game, intent(parameters))).toMatchObject({ value: { kind: 'unavailable' } });
    expect(game.room.world.position('borrow')).toBe('a:hand');
    expect(game.room.history.facts('card.used')).toHaveLength(0);
  },
);

it('受害者可以是借刀者；禁止锦囊指定受害者不冒充禁止指定真正目标', async () => {
  const game = cardGame({
    hands: { a: [card('borrow', 'collateral')], b: [card('slash', 'slash')] },
    equipment: { b: [card('weapon', 'crossbow')] },
    policy: {
      prohibitTarget: (_ctx, _actor, target, face) =>
        face.name === 'standard:collateral' && target === 'a',
    },
  });
  const running = use(game, intent({ victim: 'a' }));
  await answer(game, { kind: 'physical', card: 'slash' });
  await running;
  expect(game.room.world.player('a').hp).toBe(3);
  expect(game.room.world.position('weapon')).toBe('b:equipment');
});

it('没有任何合法杀目标或持武器者被禁止时，借刀不可用', async () => {
  for (const prohibitTarget of [
    (_ctx: unknown, _from: string, _to: string, face: { name: string }) =>
      face.name === 'standard:slash',
    (_ctx: unknown, _from: string, to: string, face: { name: string }) =>
      face.name === 'standard:collateral' && to === 'b',
  ]) {
    const game = cardGame({
      hands: { a: [card('borrow', 'collateral')] },
      equipment: { b: [card('weapon', 'crossbow')] },
      policy: { prohibitTarget },
    });
    expect(await use(game, { ...intent(), parameters: undefined })).toMatchObject({
      value: { kind: 'unavailable' },
    });
    expect(game.room.decisions.pending).toHaveLength(0);
  }
});

it('杀被仁王盾抵消仍已履行用杀，不再交武器', async () => {
  const game = cardGame({
    hands: { a: [card('borrow', 'collateral')], b: [card('s', 'slash')] },
    equipment: { b: [card('weapon', 'crossbow')], c: [card('shield', 'nioh_shield')] },
  });
  const running = use(game, intent());
  await answer(game, { kind: 'physical', card: 's' });
  await running;
  expect(game.room.world.player('c').hp).toBe(4);
  expect(game.room.world.position('weapon')).toBe('b:equipment');
  expect(game.room.history.facts('equipment.blocked')).toHaveLength(1);
  expect(game.room.history.facts('collateral.weapon-taken')).toHaveLength(0);
});

it('被要求的杀可用转换配方，仍是用牌而非打出响应', async () => {
  const game = cardGame({
    hands: { a: [card('borrow', 'collateral')], b: [card('red', 'peach', 'heart')] },
    equipment: { b: [card('weapon', 'crossbow')] },
    skills: [wusheng],
  });
  await game.room.run('grant', async (ctx) => {
    await game.skills.grant(ctx, {
      owner: 'b',
      skill: wusheng.id,
      source: { kind: 'general', id: 'guan-yu' },
    });
  });
  const running = use(game, intent());
  const request = await nextRequest(game.room);
  const offer = (request.data as { offers: CardOffer[] }).offers.find(
    (offer) => offer.label === '武圣',
  )!;
  await answer(game, { kind: 'viewAs', ...offer.choice, materials: ['red'] });
  await running;
  expect(game.room.world.player('c').hp).toBe(3);
  expect(game.room.world.position('red')).toBe('discard');
  expect(game.room.history.facts('card.responded')).toHaveLength(0);
});

it('借刀额外用杀不受出牌阶段限次影响，也不消耗新的阶段次数', async () => {
  const game = cardGame({
    hands: {
      a: [card('borrow', 'collateral')],
      b: [card('s0', 'slash'), card('s1', 'slash'), card('s2', 'slash')],
    },
    equipment: { b: [card('weapon', 'qinggang_sword')] },
  });
  const running = game.room.run('play', (ctx) =>
    withLifetime(ctx, 'play', async (at, phase) => {
      const play = {
        actor: 'b',
        choice: { kind: 'physical', card: 's0' },
        targets: ['c'],
        timing: { kind: 'play', owner: 'b', phase },
      } as const;
      await game.book.use(at, play);
      await game.book.use(at, intent());
      expect(
        game.book.validateUse(at, { ...play, choice: { kind: 'physical', card: 's2' } }),
      ).toMatchObject({ ok: false, reason: 'Usage limit reached.' });
    }),
  );
  await answer(game, { kind: 'physical', card: 's1' });
  await running;
  expect(game.room.world.player('c').hp).toBe(2);
});

it.each([false, true])('拒绝用杀时只取结算当前的武器：替换 %s', async (replace) => {
  const game = cardGame({
    hands: { a: [card('borrow', 'collateral')], b: replace ? [card('new', 'qinggang_sword')] : [] },
    equipment: { b: [card('weapon', 'crossbow')] },
  });
  game.room.on(useDeclared, {
    id: 'change-weapon',
    owner: null,
    eligible: (_ctx, use) => use.card.name === 'standard:collateral',
    async run(ctx) {
      if (replace) await equip(ctx, game.book, { card: 'new', owner: 'b', from: 'b:hand' });
      else
        await moveCards(
          ctx,
          [{ cards: ['weapon'], from: 'b:equipment', to: 'd:hand', place: 'bottom' }],
          'probe:take',
        );
    },
  });
  await use(game, intent());
  expect(game.room.world.position('weapon')).toBe(replace ? 'discard' : 'd:hand');
  if (replace) expect(game.room.world.position('new')).toBe('a:hand');
  else expect(game.room.history.facts('collateral.weapon-taken')).toHaveLength(0);
});

it('持武器者死亡则跳过；受害者死亡导致无法出杀时执行交武器分支', async () => {
  for (const target of ['b', 'c']) {
    const game = create(1);
    killPlayer(game, target);
    await use(game, intent());
    expect(game.room.world.position('weapon')).toBe(target === 'b' ? 'discard' : 'a:hand');
    expect(game.room.history.facts('card.used')).toHaveLength(1);
  }
});

it.each([0, 1])('借刀者死亡不吞掉已宣告效果，但不会获得武器：杀数量 %s', async (count) => {
  const game = create(count);
  killPlayer(game, 'a');
  const running = use(game, intent());
  if (count) await answer(game, { kind: 'physical', card: 's0' });
  await running;
  expect(game.room.world.player('c').hp).toBe(count ? 3 : 4);
  expect(game.room.world.position('weapon')).toBe('b:equipment');
});

it('无懈只反制持武器者上的借刀效果，不向附属目标再开一份锦囊效果', async () => {
  const game = cardGame({
    hands: { a: [card('borrow', 'collateral')], c: [card('n', 'nullification')] },
    equipment: { b: [card('weapon', 'crossbow')] },
  });
  installCounterspells(game.room, game.book);
  const running = use(game, intent());
  await answer(game, { kind: 'physical', card: 'n' });
  const result = await running;
  expect(result).toMatchObject({
    value: { use: { effects: [{ target: 'b', state: 'cancelled' }] } },
  });
  expect(game.room.world.position('weapon')).toBe('b:equipment');
  expect(game.room.history.facts('collateral.weapon-taken')).toHaveLength(0);
});

it('转移真正目标保留已声明受害者，重复效果各自完整用杀', async () => {
  for (const replace of [false, true]) {
    const game = cardGame({
      hands: {
        a: [card('borrow', 'collateral')],
        b: [card('b0', 'slash'), card('b1', 'slash')],
        d: [card('d0', 'slash')],
      },
      equipment: { b: [card('bw', 'crossbow')], d: [card('dw', 'crossbow')] },
    });
    game.room.on(useDeclared, {
      id: 'edit',
      owner: null,
      eligible: (_ctx, use) => use.card.name === 'standard:collateral',
      run: (ctx, use) => {
        if (replace) use.replaceTarget(ctx, use.effects[0]!.effectId, 'd', 'probe:transfer');
        else use.repeatTarget(ctx, 'b', 'probe:repeat');
      },
    });
    const running = use(game, intent());
    await answer(game, { kind: 'physical', card: replace ? 'd0' : 'b0' });
    if (!replace) await answer(game, { kind: 'physical', card: 'b1' });
    await running;
    expect(game.room.world.player('c').hp).toBe(replace ? 3 : 2);
    expect(game.room.world.position('bw')).toBe('b:equipment');
    expect(game.room.world.position('dw')).toBe('d:equipment');
  }
});

it('外部修改预填参数不改变已宣告受害者', async () => {
  const game = create(1);
  const input = { victim: 'c' };
  const running = use(game, intent(input));
  const request = await nextRequest(game.room);
  input.victim = 'a';
  await answer(game, { kind: 'physical', card: 's0' });
  await running;
  expect(request.data).toMatchObject({ targets: ['c'] });
  expect(game.room.world.player('c').hp).toBe(3);
  expect(game.room.world.player('a').hp).toBe(4);
});
