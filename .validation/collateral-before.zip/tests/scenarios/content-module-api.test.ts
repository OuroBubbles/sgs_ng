import { expect, it } from 'vitest';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { bundleContent } from '../../scripts/build-content.mjs';
import {
  instantiateContentModule,
  stageContentModules,
} from '../../src/app/offline/content-modules';
import type { LoadedContentModule } from '../../src/app/offline/content-modules';
import { availablePackages, createOfflineMatch } from '../../src/app/offline/practice';
import { definePackage, resolvePackages, damage } from '../../src/sdk';
import { leaseContentAssets } from '../../src/app/offline/content-assets';
import { nextRequest } from '../fixtures/room';
import { rebuildWorld } from '../../src/core/history/rebuild';

const sourceModule = (source: string): Promise<unknown> =>
  import('data:text/javascript;base64,' + Buffer.from(source).toString('base64'));
async function load(
  entry: string,
  providers: readonly LoadedContentModule[] = [],
): Promise<LoadedContentModule> {
  const source = await bundleContent(entry);
  return {
    fileName: entry,
    source,
    ...instantiateContentModule(await sourceModule(source), leaseContentAssets([]), providers),
  };
}
const harbor = await load('examples/content/harbor/index.ts');
const gallery = await load('examples/content/gallery/index.ts', [harbor]);

it('真实独立画阁模块直接订阅渡口的 Window 和 Query，不复制依赖实现', () => {
  expect(gallery.source.includes('"harbor.provisionFinished"')).toBe(false);
  expect(gallery.source.includes('"harbor.tideDrawBonus"')).toBe(false);
  const ink = (
    gallery.package.skills as readonly {
      effects: readonly { window: object }[];
      modifiers: readonly { query: object }[];
    }[]
  )[0]!;
  expect(ink.effects[0]!.window).toBe(harbor.exports!.provisionFinished);
  expect(ink.modifiers[0]!.query).toBe(harbor.exports!.tideDrawBonus);
  expect(
    (harbor.exports!.provisionBy as (event: { actor: string }, owner: string) => boolean)(
      { actor: '甲席' },
      '乙席',
    ),
  ).toBe(false);
});

it('真实备航和潮声经跨模块查询多摸一张，完成窗口触发墨韵回复，状态可由事实重建', async () => {
  const content = resolvePackages(
    stageContentModules(availablePackages, [gallery.package, harbor.package]),
    ['gallery'],
  );
  const match = createOfflineMatch(
    2,
    2,
    'harbor:crossing',
    ['gallery:guest', 'standard:guanyu'],
    content,
  );
  await match.prepare();
  await match.room.run('wound', (ctx) =>
    damage(ctx, { from: null, to: '甲席', amount: 1, nature: 'normal' }),
  );
  expect(match.room.world.player('甲席').hp).toBe(3);
  const before = match.room.world.zone('甲席:hand').cards.length;
  const card = match.room.world
    .zone('甲席:hand')
    .cards.find((id) => match.room.world.card(id).name === 'harbor:provision')!;
  expect(card).toBeTruthy();
  const running = match.room.run('provision', (ctx) =>
    match.book.use(ctx, {
      actor: '甲席',
      choice: { kind: 'physical', card },
      targets: ['甲席'],
      timing: { kind: 'effect' },
    }),
  );
  for (const skill of ['harbor:tide', 'gallery:ink']) {
    const request = await nextRequest(match.room);
    expect(request).toMatchObject({ kind: 'invoke', data: { skill } });
    expect(match.room.decisions.submit(request.id, request.token, true)).toEqual({
      kind: 'accepted',
    });
  }
  await running;
  expect(match.room.world.zone('甲席:hand').cards).toHaveLength(before + 3);
  expect(match.room.world.player('甲席').hp).toBe(4);
  expect(match.room.world.position(card)).toBe('discard');
  expect(match.room.decisions.pending).toEqual([]);
  expect(rebuildWorld(match.initial, match.room.history.facts())).toEqual(
    match.room.world.snapshot,
  );
  match.room.abort('done');
});

it('普通命名/default 导入与转导出保留函数、class、闭包及 live binding，不重跑提供方', async () => {
  const folder = resolve('.artifacts/module-api-test');
  await mkdir(folder, { recursive: true });
  const provider = resolve(folder, 'provider.ts');
  await writeFile(
    provider,
    `import { definePackage } from '@sgs/sdk';
export let count = 0; export function increment() { return ++count; }
export class Marker {};
export default definePackage({manifest:{id:'provider',name:'Provider',version:'1'}});`,
  );
  const consumer = resolve(folder, 'consumer.ts');
  await writeFile(
    consumer,
    `import { definePackage } from '@sgs/sdk';
import pack, * as namespace from '@sgs/content/provider';
import { count, increment, Marker } from '@sgs/content/provider';
export { increment, Marker }; export function read() { return count; } export function original() { return pack; } export function originalNamespace() { return namespace; }
export default definePackage({manifest:{id:'consumer',name:'Consumer',version:'1',requires:[{id:'provider',version:'1'}]}});`,
  );
  const one = await load(provider);
  const two = await load(consumer, [one]);
  const three = await load(consumer, [one]);
  expect(two.exports!.increment).toBe(one.exports!.increment);
  expect(two.exports!.Marker).toBe(one.exports!.Marker);
  expect((two.exports!.original as () => unknown)()).toBe(one.exports!.default);
  expect((two.exports!.originalNamespace as () => unknown)()).toBe(one.exports);
  expect((two.exports!.increment as () => number)()).toBe(1);
  expect((three.exports!.read as () => number)()).toBe(1);
  expect((two.exports!.increment as () => number)()).toBe(2);
  expect((two.exports!.read as () => number)()).toBe(2);
  const fresh = await load(provider);
  expect(fresh.exports!.increment).not.toBe(one.exports!.increment);
  expect(fresh.exports!.count).toBe(0);
});

const compiled = (requires: readonly { id: string; version?: string }[] = []) => ({
  format: 'sgs-content/1',
  imports: ['harbor'],
  default: () => undefined,
  createNamespace: () => ({
    default: definePackage({
      manifest: { id: 'consumer', name: 'Consumer', version: '1', requires },
    }),
  }),
});
it('代码依赖缺失、未显式声明及精确版本不符均明确拒绝', () => {
  expect(() => instantiateContentModule(compiled())).toThrow('缺少代码依赖：harbor');
  expect(() => instantiateContentModule(compiled(), leaseContentAssets([]), [harbor])).toThrow(
    'manifest.requires',
  );
  expect(() =>
    instantiateContentModule(
      compiled([{ id: 'harbor', version: 'wrong' }]),
      leaseContentAssets([]),
      [harbor],
    ),
  ).toThrow('版本不符');
});
it.each([null, ['harbor', 'harbor'], ['harbor/private'], [1], 'harbor'])(
  '不接受非法代码依赖列表 %j',
  (imports) => {
    expect(() => instantiateContentModule({ ...compiled(), imports })).toThrow(
      '代码依赖声明不正确',
    );
  },
);
it('构建诊断代码子路径导入，类型专用 import 不产生运行依赖', async () => {
  const entry = resolve('.artifacts/module-api-test/type-only.ts');
  await mkdir(resolve('.artifacts/module-api-test'), { recursive: true });
  await writeFile(
    entry,
    `import { definePackage } from '@sgs/sdk'; import type { ProvisionResult } from '@sgs/content/harbor';
export function actor(event: ProvisionResult) { return event.actor; }
export default definePackage({manifest:{id:'types',name:'Types',version:'1'}});`,
  );
  const module = (await sourceModule(await bundleContent(entry))) as { imports: readonly string[] };
  expect(module.imports).toEqual([]);
  await writeFile(entry, `export { default } from '@sgs/content/harbor/private';`);
  await expect(bundleContent(entry)).rejects.toThrow('Import a package entry');
});

it('作者可使用 exports/require 及宿主参数同名局部，不泄露编译胶水命名限制', async () => {
  const entry = resolve('.artifacts/module-api-test/names.ts');
  await mkdir(resolve('.artifacts/module-api-test'), { recursive: true });
  await writeFile(
    entry,
    `import {definePackage} from '@sgs/sdk';
const __sgs_local_exports = 7; export const exports = 2, require = 1, sdk = 3, assets = 4, modules = 5, namespace = 6;
export let count = 0; export function increment(exports: number, require: number) { return ++count + exports + require; }
export function values() { const local = { exports, require }; return [local.exports,local.require,__sgs_local_exports]; }
export default definePackage({manifest:{id:'names',name:'Names',version:'1'}});`,
  );
  const loaded = await load(entry);
  expect(loaded.exports).toMatchObject({
    exports: 2,
    require: 1,
    sdk: 3,
    assets: 4,
    modules: 5,
    namespace: 6,
  });
  expect((loaded.exports!.values as () => number[])()).toEqual([2, 1, 7]);
  expect((loaded.exports!.increment as (exports: number, require: number) => number)(2, 3)).toBe(6);
  expect(loaded.exports!.count).toBe(1);
  const publicNames = resolve('.artifacts/module-api-test/public-names.ts');
  await writeFile(
    publicNames,
    `import {definePackage} from '@sgs/sdk';
const first = 8, second = 9; export {first as exports, second as require};
export function destructure({exports = 2, require = 3}: {exports?: number; require?: number}) { return {exports,require}; }
export default definePackage({manifest:{id:'publicnames',name:'Public names',version:'1'}});`,
  );
  const publicModule = await load(publicNames);
  expect(publicModule.exports).toMatchObject({ exports: 8, require: 9 });
  expect((publicModule.exports!.destructure as (input: object) => object)({})).toEqual({
    exports: 2,
    require: 3,
  });
});

it('初始化保持同步，技能函数仍可 await，本地异步函数不被初始化检查误拒绝', async () => {
  const entry = resolve('.artifacts/module-api-test/initialization.ts');
  await mkdir(resolve('.artifacts/module-api-test'), { recursive: true });
  await writeFile(
    entry,
    `import {definePackage} from '@sgs/sdk'; export const later = async () => await Promise.resolve(3); export default definePackage({manifest:{id:'later',name:'Later',version:'1'}});`,
  );
  const loaded = await load(entry);
  expect(await (loaded.exports!.later as () => Promise<number>)()).toBe(3);
  await writeFile(
    entry,
    `import {definePackage} from '@sgs/sdk'; await Promise.resolve(); export default definePackage({manifest:{id:'later',name:'Later',version:'1'}});`,
  );
  await expect(bundleContent(entry)).rejects.toThrow('initialization must be synchronous');
});
