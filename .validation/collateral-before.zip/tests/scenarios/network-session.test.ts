import { afterEach, expect, it, vi } from 'vitest';
import { createGameServer } from '../../src/server/server';
import { RemoteSession } from '../../src/app/network/session';
import { createOfflineMatch } from '../../src/app/offline/practice';
import { projectMatch } from '../../src/app/offline/projection';
import { observeAgent } from '../../src/app/offline/agent-observation';
import { decideBasic } from '../../src/app/offline/basic-agent';
import { rebuildWorld } from '../../src/core/history/rebuild';
import { inspectSelection } from '../../src/app/offline/selection';
import { matchPrepared } from '../../src/app/offline/role-match';

const cleanup: (() => void | Promise<void>)[] = [];
afterEach(async () => {
  for (const dispose of cleanup.splice(0).reverse()) await dispose();
});

async function connect(aiDelayMs = 0) {
  const match = createOfflineMatch(4, 42, 'standard:identity', [
    'standard:guanyu',
    'standard:caocao',
    'standard:zhangfei',
    'standard:zhaoyun',
  ]);
  const host = createGameServer(match, { humans: ['甲席', '乙席'], aiDelayMs });
  const port = await host.listen(0);
  cleanup.push(() => host.close());
  const initial = projectMatch(match, null, null);
  const clients = [
    new RemoteSession(`ws://127.0.0.1:${port}/game`, initial),
    new RemoteSession(`ws://127.0.0.1:${port}/game`, initial),
  ];
  cleanup.push(() => {
    for (const client of clients) client.dispose();
  });
  await vi.waitFor(() => {
    expect(clients.every((client) => client.lobby?.seats.every((seat) => seat.connected))).toBe(
      true,
    );
  });
  return { match, clients, port, initial };
}

it('托管仅作用于绑定席位；拒绝迟到手动答案，隐藏期间可收回且原请求保持', async () => {
  const { match, clients } = await connect(500);
  match.room.on(matchPrepared, {
    id: 'controller-choice',
    owner: null,
    eligible: () => true,
    async run(ctx) {
      await ctx.ask({
        player: '甲席',
        kind: 'choose-option',
        prompt: '控制权',
        data: { options: [{ id: 'ok', label: '确认', selectable: true }] },
        optional: false,
        validate: (input) =>
          input === 'ok' ? { ok: true, value: input } : { ok: false, reason: 'invalid' },
      });
    },
  });
  for (const client of clients) client.start();
  const self = clients[0]!,
    other = clients[1]!;
  await vi.waitFor(() => expect(self.view.decision?.kind).toBe('choose-option'));
  const request = self.view.decision!;
  const before = match.room.world.snapshot;
  expect(await self.setDelegated(true)).toEqual({ kind: 'accepted' });
  await vi.waitFor(() => expect(self.view.control?.delegated).toBe(true));
  expect(other.view.control?.delegated).toBe(false);
  expect(self.view.decision).toBeNull();
  expect(await self.answer(request.id, request.token, 'ok')).toMatchObject({ kind: 'rejected' });
  self.hide();
  expect(await self.setDelegated(false)).toEqual({ kind: 'accepted' });
  self.resume();
  await vi.waitFor(() => expect(self.view.decision?.id).toBe(request.id));
  await new Promise((resolve) => setTimeout(resolve, 600));
  expect(match.room.world.snapshot).toEqual(before);
  expect(self.view.decision).toMatchObject({ id: request.id, token: request.token });
  expect(await self.answer(request.id, request.token, 'ok')).toEqual({ kind: 'accepted' });
});

it('两个绑定席位托管后由基础 AI 完整结算身份局', async () => {
  const { match, clients } = await connect();
  for (const client of clients) client.start();
  await vi.waitFor(() => expect(match.progress).not.toBeNull());
  for (const client of clients)
    expect(await client.setDelegated(true)).toEqual({ kind: 'accepted' });
  await vi.waitFor(() => expect(match.result).not.toBeNull(), { timeout: 15_000, interval: 10 });
  await vi.waitFor(() => expect(clients.every((client) => client.view.result)).toBe(true));
  expect(clients.map((client) => client.view.viewer)).toEqual(['甲席', '乙席']);
  expect(clients.every((client) => client.view.control?.delegated && !client.view.decision)).toBe(
    true,
  );
  expect(match.room.decisions.pending).toEqual([]);
  expect(match.room.world.snapshot.cards).toHaveLength(108);
  expect(rebuildWorld(match.initial, match.room.history.facts())).toEqual(
    match.room.world.snapshot,
  );
}, 20_000);

it('两个真实 WebSocket 客户端绑定不同席位，复用预览并完整结算身份局', async () => {
  const { match, clients } = await connect();
  expect(clients.map((client) => client.human)).toEqual(['甲席', '乙席']);
  for (const client of clients) client.start();
  let decisions = 0;
  let previewed = false;
  const acted = new Set<string>();
  while (!match.result) {
    await vi.waitFor(
      () => {
        expect(match.room.status).not.toBe('faulted');
        expect(match.result || clients.some((client) => client.view.decision)).toBeTruthy();
      },
      { timeout: 10_000, interval: 1 },
    );
    if (match.result) break;
    const client = clients.find((client) => client.view.decision)!;
    const decision = client.view.decision!;
    const request = match.room.decisions.pending.find((request) => request.id === decision.id)!;
    const other = clients.find((item) => item !== client)!;
    // 每席只收到自己的手牌与决策，原始请求中的 choice/闭包未进入协议。
    expect(other.view.decision).toBeNull();
    for (const viewer of clients) {
      expect(viewer.view.handoff).toBeNull();
      expect(viewer.view.hand.map((card) => card.id)).toEqual([
        ...match.room.world.zone(`${viewer.human}:hand`).cards,
      ]);
      expect(JSON.stringify(viewer.view)).not.toContain('"choice":');
      expect(
        viewer.view.pools.every(
          (pool) => pool.visibility !== 'private' || pool.zone.startsWith(viewer.human!),
        ),
      ).toBe(true);
    }
    expect(await other.cancel(decision.id, decision.token)).toMatchObject({
      kind: 'rejected',
      reason: 'closed',
    });
    expect(await client.cancel(decision.id, decision.token + 1)).toMatchObject({
      kind: 'rejected',
    });
    if (!previewed && 'offers' in decision && decision.offers.length) {
      const selection = { offer: decision.offers[0]!.id, cards: [], targets: [] };
      const expected = inspectSelection(match, request, selection);
      await vi.waitFor(
        () =>
          expect(client.inspect(decision.id, decision.token, selection).reason).not.toBe(
            '正在核对选择…',
          ),
        { interval: 1 },
      );
      expect(client.inspect(decision.id, decision.token, selection)).toEqual(expected);
      previewed = true;
    }
    // 测试操作者通过真实网络回答；正式客户端不会取得这里的主持端观察。
    const answer = decideBasic(observeAgent(match, request.player), request, (value) =>
      match.room.decisions.preview(request.id, value),
    );
    if (answer.kind === 'unsupported') throw new Error(answer.reason);
    expect(
      await (answer.kind === 'cancel'
        ? client.cancel(decision.id, decision.token)
        : client.answer(decision.id, decision.token, answer.value)),
    ).toEqual({ kind: 'accepted' });
    acted.add(client.human!);
    expect(await client.cancel(decision.id, decision.token)).toMatchObject({ kind: 'rejected' });
    if (++decisions > 1800) throw new Error('Network game decision budget exhausted.');
  }
  await vi.waitFor(() => expect(clients.every((client) => client.view.result)).toBe(true), {
    interval: 1,
  });
  expect(acted).toEqual(new Set(['甲席', '乙席']));
  expect(previewed).toBe(true);
  expect(clients[0]!.view.result).toEqual(clients[1]!.view.result);
  expect(match.room.decisions.pending).toEqual([]);
  expect(match.room.world.snapshot.cards).toHaveLength(108);
  expect(match.room.world.snapshot.zones.some((zone) => zone.kind === 'processing')).toBe(false);
  expect(match.room.history.facts('game.finished')).toHaveLength(1);
  expect(rebuildWorld(match.initial, match.room.history.facts())).toEqual(
    match.room.world.snapshot,
  );
}, 30_000);

it('开局前可补位，中途断线结束本局且不能接管挂起协程', async () => {
  const { match, clients, port, initial } = await connect();
  clients[1]!.dispose();
  await vi.waitFor(() => expect(clients[0]!.lobby?.seats[1]?.connected).toBe(false));
  const replacement = new RemoteSession(`ws://127.0.0.1:${port}/game`, initial);
  cleanup.push(() => replacement.dispose());
  await vi.waitFor(() => expect(replacement.human).toBe('乙席'));
  clients[0]!.start();
  replacement.start();
  await vi.waitFor(() => expect(match.progress).not.toBeNull());
  replacement.dispose();
  await vi.waitFor(() => expect(clients[0]!.view.error).toContain('乙席 已断开'));
  expect(match.room.decisions.pending).toEqual([]);
  const late = new RemoteSession(`ws://127.0.0.1:${port}/game`, initial);
  cleanup.push(() => late.dispose());
  await vi.waitFor(() => expect(late.view.error).toContain('房间已满或已经开局'));
  expect(late.human).toBeNull();
});

it('作者校验异常向两端报告原始故障，不误报客户端消息格式错误', async () => {
  const { match, clients } = await connect();
  match.room.on(matchPrepared, {
    id: 'author-validation',
    owner: null,
    eligible: () => true,
    async run(ctx) {
      await ctx.ask({
        player: '甲席',
        kind: 'choose-option',
        prompt: '作者校验',
        optional: false,
        data: { options: [{ id: 'inspect', label: '核对', selectable: true }] },
        validate() {
          throw new Error('作者校验故障');
        },
      });
    },
  });
  for (const client of clients) client.start();
  await vi.waitFor(() => expect(clients[0]!.view.decision?.kind).toBe('choose-option'));
  const before = match.room.world.snapshot;
  const request = clients[0]!.view.decision!;
  clients[0]!.inspectAnswer(request.id, request.token, 'inspect');
  await vi.waitFor(() => {
    for (const client of clients) {
      expect(client.view.status).toBe('faulted');
      expect(client.view.error).toBe('作者校验故障');
      expect(client.lobby?.seats.every((seat) => seat.connected)).toBe(true);
    }
  });
  expect(match.room.decisions.pending).toEqual([]);
  expect(match.room.world.snapshot).toEqual(before);
  expect(rebuildWorld(match.initial, match.room.history.facts())).toEqual(before);
});
