import { expect } from 'vitest';
import { setImmediate } from 'node:timers/promises';
import type { RoleMatch } from '../../src/app/offline/role-match';
import { observeAgent } from '../../src/app/offline/agent-observation';
import { decideBasic } from '../../src/app/offline/basic-agent';

/** 启动并完成真实对局，统一驱动与清理；阵容、预算和领域断言仍由场景负责。 */
export async function playMatch(
  match: RoleMatch,
  budget: { readonly steps: number; readonly decisions?: number },
): Promise<number> {
  const running = match.start();
  let decisions = 0;

  try {
    for (let step = 0; step < budget.steps && !match.result; step++) {
      await setImmediate();
      expect(match.room.status).not.toBe('faulted');
      const request = match.room.decisions.pending[0];
      if (!request) continue;
      if (decisions >= (budget.decisions ?? Infinity))
        throw new Error(`${request.prompt}: decision budget exhausted.`);

      const answer = decideBasic(observeAgent(match, request.player), request, (input) =>
        match.room.decisions.preview(request.id, input),
      );
      if (answer.kind === 'unsupported') throw new Error(`${request.prompt}: ${answer.reason}`);
      const accepted =
        answer.kind === 'cancel'
          ? match.room.decisions.cancel(request.id, request.token)
          : match.room.decisions.submit(request.id, request.token, answer.value);
      expect(accepted, request.prompt).toEqual({ kind: 'accepted' });
      decisions++;
    }

    expect(match.result, `${decisions} decisions / ${match.progress?.turns} turns`).not.toBeNull();
    expect(await running).toMatchObject({ kind: 'resolved', value: match.result });
    return decisions;
  } finally {
    match.room.abort('test cleanup');
    await running;
  }
}
