# 16 · 正式规则客户端与本地单机

更新：2026-10-25。主入口已从 P0 演示状态替换为正式 RoleMatch，浏览器可通过实际界面从开局走到身份胜负。默认标准＋EX 为 32 种牌、108 张实体牌，另可选择机制练习（见 [23 · 两件剑与标准牌组](23-swords-standard-deck.md)）。当前可选二十五名标准武将，AI 席位可保留循环预设或统一指定武将；目录与主动技能边界见 [27](27-generals-active-skills.md)，弃置与新增武将见 [28](28-discard-martial-generals.md)，魏将与判定/回合效果见 [29](29-wei-judgment-effects.md)，谋士与私有牌池见 [30](30-strategists-private-pools.md)。

默认固定人类控制甲席，其余角色使用基础 AI，不再交接设备。本人可托管给同一策略并收回，手动多席操作保留为内容调试选项。平台与交付范围见 [STATUS](STATUS.md)。

## 所有权与数据流

```mermaid
flowchart LR
  R[RoleMatch / Room] --> J[提交事实与决策通知]
  J --> H[LocalSession 本地主持侧]
  H --> P[席位投影]
  P --> V[Svelte / Pixi]
  V --> S[未提交选择]
  S --> H
  H --> D[DecisionHub 预览与最终验证]
  D --> R
```

[LocalSession](../src/app/offline/session.ts) 持有执行者、查看许可、订阅与输入转发。[GameView](../src/core/view/game.ts) 只有展示数据，不携带 World、原始历史 detail 或执行闭包。组件不导入规则模块，也不计算杀的距离、用牌次数、桃的目标等规则。

主控席位由主持侧固定，基础 AI 只拿到独立的信息受限观察，通过同一 DecisionHub 预览与提交。AI 私有请求不会进入人类视图；`automated` 只标识当前等待的角色，`control` 表达本人托管状态与交还原因，`paused` 标识主持侧暂停状态。策略与调度边界见 [26](26-basic-ai.md)。

[投影](../src/app/offline/projection.ts) 显示公共体力、性别、存活、手牌数量、装备与技能；身份只显示主公、当前本人、已死亡角色，终局揭示全表。单机视图只包含甲席手牌；手动演练只包含当前确认席位的手牌。其他人的牌不通过隐藏 DOM 保存。

日志只解释已明确公开的事实：摸牌数量、公开用牌/响应、体力变化、弃牌数量、死亡和胜负。原始洗牌顺序、起手内容和选择细节不透传。最近用牌保存语义牌快照，处理状态只追踪已宣告公开的材料；不能把任意 processing 区域都当作公开牌。

Journal 按提交、决策开放/关闭和故障异步通知，避免在提交中执行组件代码。订阅释放后不再调用观察者；Room 的权威执行不等待动画、帧率或视图更新。

本地投影出错时主持侧停止本局并撤销 AI 待执行任务，保留原始错误与已提交事实。错误视图使用印刷牌面，避免再次执行失效的修正规则；运行核已经故障时也采用同一路径。单独调用 Room.inspect 的错误仍只关闭自身只读上下文，不冻结运行核。

主持侧预览、提交及请求刷新中的规则异常也走同一停止/报告路径，对界面返回不可操作结果。组件通知异步发布，避免派生预览同步改写组件状态。普通不合法选择仍返回可重选的校验结果；代码故障关闭本局。

## 固定主控与手动演练

单机自动确认 seat-ready 并控制非主控角色。自己的身份、手牌与右下席位不因其他角色出牌、响应或救援而切换；人类不能代答 AI 请求。暂停和后台事件会藏牌、撤销 AI 定时任务；恢复后明确点击继续。已经提交的规则结算正常善后，在下一次决策处等待。

勾选“手动演练（内容调试）”时，每回合的 seat-ready 需要本人确认。响应或救援切换操作者时，也先撤销上一席位许可：投影手牌为空、私有决策为空，清除已选材料、目标和详情，再显示原生 dialog 交接遮罩。Esc 不能绕过交接。交接令牌匹配当前请求；旧令牌不能开启后来的请求。

手动演练的“隐藏手牌”和页面隐藏事件会撤销查看许可，恢复后重新确认。它们不移动牌、不消耗次数、不推进回合。演练模式的所有席位均由人操作；没有账户或联机控制。

## 决策与交互

| 执行侧决策    | 当前界面                                                                      |
| ------------- | ----------------------------------------------------------------------------- |
| play-action   | 选实体/转换牌或主动技能、明确确认；技能自行组织后续选择，取消表示结束出牌阶段 |
| card-response | 闪/决斗中的杀，可打出或放弃                                                   |
| use-card      | 固定用途用牌；救援桃与锦囊反制不需要手工目标                                  |
| cards-targets | 手牌/公开牌池/私有选项、多目标反馈、强制弃牌不可取消                          |
| invoke        | 发动 / 不发动                                                                 |
| trigger-order | 可读技能名按钮，回复稳定 ID                                                   |
| choose-option | 具名选项以可读按钮显示，回复稳定 ID                                           |
| arrange       | 有序分组、组内前后移动、上下限预览与最终确认；暂停隐藏私有内容                |
| 其他          | 明确显示尚无该类面板，不自动取消或伪造回复                                    |

`CardBook.inspectUse` 在执行侧生成目标部分选择反馈，最终确认完整复用 validateUse。选择未完成也能区别可选目标与不可选目标。切换单目标时可以替换已选者；换牌时只保留仍合法的目标；预览不支付。转换配方支持零/多材料数量，有序分组/排序专用面板已接入；任意参数表单和带角色额度的分配仍未实现，见 [37](37-arrangement-astrology.md)。

Svelte 的草稿可能是 Proxy，LocalSession 在输入边界把材料和目标复制为普通数组。不能把响应式草稿直接交给 structuredClone，也不能为方便 UI 放宽规则层的普通数据要求。已有回归场景使用代理数组验证这个边界。

[手牌](../src/client/panels/HandCard.svelte) 保留右键/触摸长按详情，滑动取消长按。大手牌通过容器内横向滚动访问；快捷键 1–9 选牌，Enter 确认，Esc 清除草稿。输入框、详情、动画模态和交接遮罩期间不截获游戏快捷键。

[布局](../src/client/table/layout.ts) 为 2–8 个席位计算唯一矩形；Pixi 绘制与 DOM 命中区域共用坐标。单机始终以甲席为焦点，暂停也保留位置；手动演练以当前确认角色为焦点，无查看许可时使用活动角色。本人固定右下；手牌左下、确认居中在上、技能邻近本人，牌堆右上、记录从左打开，区域契约见 [25](25-table-position.md)。可选、已选与不可选状态来自决策反馈。开局设置支持 2/4/6/8 人、标准/机制牌组和确定性种子；战场标题显示实际装配的牌组。真实角色性别来自武将；手动演练仍使用交替性别的机制角色。

参考本地 noname 的 [game.check](../../noname/resources/app/noname/game/index.js)（约 6941 行）与 [十周年 UI checkTarget](../../noname/resources/app/extension/十周年UI/extension.js)（约 3015 行）：分别更新牌、目标和确认状态，明显区分可选/已选。只吸收交互逻辑，没有导入其全局对象或源码。

## 验证入口

- [主持侧场景](../tests/scenarios/local-session.test.ts) 覆盖私有投影、授权、隐藏、关闭与真实规则回复；[基础 AI](../tests/scenarios/basic-agent.test.ts) 和 [联机会话](../tests/scenarios/network-session.test.ts) 检查控制权交接、迟到输入与托管整局。
- [浏览器场景](../tests/browser/client.spec.ts) 使用生产构建，覆盖默认单机、手动演练、选择与取消、目标反馈、技能面板、藏牌恢复和真实胜负；[联机场景](../tests/browser/network.spec.ts) 检查两个独立席位的视图与远端选择。脚本输入与 AI 自主决策分别验证，不把交互冒烟当作策略质量证明。
- 横屏与竖屏均检查手牌滚动、命中区域及详情。浏览器后台事件只证明客户端响应事件，不能代替 Android 系统生命周期验收。布局关系见 [25](25-table-position.md)。
- Windows 使用 `pnpm desktop:verify` 验证实际 WebView2、离线整局与内容跨进程恢复；`pnpm desktop:network` 验证两个独立原生客户端的真实选择、托管整局与返回单机。平台入口与环境见 [08](08-development-guide.md)。

当前结果、平台版本、报告路径与尚未验证的边界只在 [STATUS](STATUS.md) 维护；不在本契约累积各批测试数量。浏览器报告为 `.artifacts/validation/browser.json`，完整源码检查为 `.artifacts/validation/units.json`。

Windows 包与精确成员以 `.artifacts/builds/local-client-manifest.json` 为准，交付脚本核对归档字节与实际 Release 证明。内容导入与持久保存见 [本地模块](39-source-packages.md#构建与导入) / [持久恢复](39-source-packages.md#持久安装与恢复)，二进制资源见 [独立资源](39-source-packages.md#资源与所有权)；Android 的已验收范围同样以 STATUS 为准。

额外回合队列、阶段计划和连续手动投影见 [24](24-extra-turns.md)。

## 联机纵切

`pnpm online` 依次构建页面与 Node 主持端，再监听 `127.0.0.1:1422`。两个独立浏览器打开控制台给出的 `/?online=1`，先后分配甲、乙席，双方准备才开局；丙、丁席继续使用既有基础 AI。当前固定四人身份、关羽/曹操/张飞/赵云与标准牌组，默认种子 42；`SGS_SEED` 可设为 1–4294967295 的整数，例如种子 2 由甲席先手。`pnpm server:build` 和 `pnpm server:start` 可单独运行；页面需要先由 `pnpm build` 生成。`SGS_HOST` / `SGS_PORT` 只控制本进程监听地址；局域网需用实际主持机 IP 访问，自动选端口可用 0。

[NetworkRoom](../src/app/network/room.ts) 持有唯一 RoleMatch 并分配席位；[Node 入口](../src/server/server.ts) 提供同源静态页面与 `/game` WebSocket。[协议](../src/app/network/protocol.ts) 只携带该席 GameView、选择和预览结果，不发送 World、牌堆、其他席位私有决策、原始历史或校验闭包。连接不能用消息中的玩家名更换席位；每次预览、提交、取消均重核当前 Decision ID、token 和拥有者。选择草稿经 JSON 复制，合法性仍由原有 DecisionHub 计算。

[RemoteSession](../src/app/network/session.ts) 接入现有牌桌。网络预览尚未返回时禁止确认，按视图 revision、Decision ID/token 隔离缓存；不同草稿各自对应主持端结果，迟到响应不能覆盖新选择。提交等待主持端明确接受，界面忽略已结束决策的迟到错误。排序等专用回答也走同一预览/提交通道。联机藏牌只隐藏本机画面，其他人和 AI 继续行动；需要该席回答时仍等待人类。

Windows 客户端在开局页展开“加入联机”，填写 `http://主持机:端口` 或 `主机:端口`。同一个 RemoteSession 将地址规范到 `/game` WebSocket；HTTPS 使用 WSS。客户端保留自己的页面和内置资源，退出后直接回到单机开局；不会导航到远端 HTML。无效地址不关闭当前单机会话。当前标准内容要求双方使用同一构建；远端包分发尚未实现。

原生 [CSP 配置](../src-tauri/tauri.conf.json) 的 connect-src 开放 WS/WSS，保留脚本、资源和 IPC 策略；预览服务器从这份配置直接返回真实 HTTP 响应头，浏览器场景无需再伪造 HTML 响应。配置机制见 [Tauri CSP](https://v2.tauri.app/security/csp/)。`pnpm desktop:network` 沿既有 Windows 验收入口启动唯一主持进程、两个独立客户端和用户目录，完成各席真实选择、藏牌恢复、托管交接、AI 整局和返回单机；记录 `.artifacts/validation/native-network-release.json` 含实际 CSP、进程与 exe 摘要。打包前需与 `desktop:verify` 一起通过，交付脚本核对各份运行证明属于同一 exe。

开局前断线释放空位；开局后断线结束本局，不接管旧身份、手牌或挂起协程，也不以事实重建冒充续局。每个主持进程只承载一局，再开需重启。

当前仅一个标准身份局，没有账户、大厅、房间列表、重连续局和内容包分发。已验证的平台范围以 [STATUS](STATUS.md) 为准。

协议使用浏览器原生 WebSocket 和 Node [ws](https://github.com/websockets/ws)，构建输出在 `.artifacts/server/`，项目依赖固定版本；不另引入 RPC、序列化技能或多进程框架。
