# 39 · 内容包：声明、构建与恢复

内容作者使用普通可信 TypeScript，通过同一个 `definePackage` 声明牌、技能、独立效果、武将、牌组和展示资源。包可以随程序构建，也可以独立交付、安装并在重启后恢复。当前内容版本与平台验收统一见 [STATUS](STATUS.md)；本文描述当前契约。

## 作者入口

规则接口从 [SDK](../src/sdk/index.ts) 导入，技能写法见 [05](05-authoring.md)。可运行示例有：

- [演武](../src/content/workshop/index.ts)：内置作者包，展示牌、跨包技能、独立效果、连环、护盾与伤害转移。它使用公共 SDK，不依赖标准包内部实现。
- [渡口](../examples/content/harbor/index.ts)：可独立构建的牌、技能、武将、牌组与静态立绘，同时导出普通函数、自定义 Window 和 Query。
- [画阁](../examples/content/gallery/index.ts)：依赖渡口，使用同一个 Query 增加潮声摸牌，订阅同一个备航完成 Window，并复用原图。

在 `src/content/<packageId>/index.ts` 默认导出 `definePackage(...)`，[available.ts](../src/content/available.ts) 会在构建时发现内置包。外部作者使用同一声明，按下文单独构建；玩家端加载 JavaScript，不携带 TypeScript 编译器。

## 包声明

[package.ts](../src/content/package.ts) 定义包接口与装配逻辑：

| 字段           | 用途                                                                                |
| -------------- | ----------------------------------------------------------------------------------- |
| `manifest`     | `id`、可读 `name`、内容 `version`，以及可选的 `requires`                            |
| `cards`        | 普通牌定义，复用统一的宣告、支付、目标、反制与结算                                  |
| `skills`       | 技能列表，或接收本局 `CardBook` 的工厂                                              |
| `effects`      | 独立效果定义，见 [56](56-independent-effects.md)                                    |
| `generals`     | 武将属性与技能 ID，可引用自身及声明依赖中的技能                                     |
| `decks`        | `id`、`label` 和返回实体牌列表的普通 `create()` 函数                                |
| `cardViews`    | 牌 ID、显示类别与规则说明；名称取自实际牌定义                                       |
| `generalViews` | 武将 ID 与立绘 URL，独立于规则状态；展示契约见 [57](57-portraits-content-images.md) |

包 ID 和局部 ID 均为小写字母开头的字母、数字、下划线或连字符。牌、技能、效果、武将、牌组及展示声明使用 `packageId:localId`；各类别独立检查重复，不允许覆盖已有定义。

`manifest.requires` 的 `version` 省略时只要求包存在，填写时按精确字符串比较。每个 ID 只装配一个版本；不解析版本范围或择优升级。作者负责在规则内容改变时更新版本声明。

## 每局装配

`resolvePackages(available, selected)` 验证声明并解析传递依赖：根选择和每层依赖按 ID 的码点序排序，依赖先于使用者，同一包只出现一次。重复包、缺依赖、循环、版本冲突、错误命名空间和未知展示引用会报错；选中版本为冻结快照。

`content.createBooks()` 为每局新建牌、技能、效果与武将目录。全部牌先登记到真实 `CardBook`，然后按依赖顺序登记效果、调用一次各包技能工厂，最后验证武将技能。工厂产物也检查技能命名空间和重复 ID。武将不能借用偶然同时勾选、却未声明依赖的包；声明效果类型后，仍需普通规则函数添加或准备效果实例。

`content.createDeck(id)` 只执行指定牌组工厂，检查实体 ID 重复、牌名存在及所属包可见性，实体数据与区域约束仍由 World 检查。未知牌组直接报错。技能和牌是普通代码，装配器不静态分析闭包中的全部引用；作者应为代码使用的其他包声明依赖。

[RoleMatch](../src/app/offline/role-match.ts) 在创建 Room 前检查目录、牌组与角色；客户端成功构造下一局后才释放上一局。开局在洗牌、授予技能和发牌前提交 `match.content`，把有序 `{ id, version }` 写入 `content:selection`，事实重建包含该声明；无包的底层测试装配记录空清单。

每局目录与版本固定，后续内容库变化不会热换正在运行的 Room。版本事实记录声明，不保存代码归档、挂起函数或协程；它不能恢复任意时点的对局。

## 构建与导入

入口默认导出包声明，包内辅助文件使用普通相对 import：

```sh
# 单文件模块，资源内联。
pnpm content:build examples/content/harbor/index.ts .artifacts/content/harbor.sgs.mjs

# 同一份源码，资源与代码分开装入 ZIP。
pnpm content:build examples/content/harbor/index.ts .artifacts/content/harbor.sgs

# 固定示例入口：单文件渡口；渡口与画阁两个 ZIP。
pnpm content:example
pnpm content:bundle
```

[构建器](../scripts/build-content.mjs) 用 Vite 处理 TypeScript 与资源，再由 Rollup 包装为 `sgs-content/1` 模块工厂。SDK 保留为宿主参数，外部代码依赖保留为包入口引用；Window、Query、函数和运行期类不会因重新打包 SDK 而产生第二份身份。误导入包目录外的宿主实现会被诊断，作者无需手写工厂包装。

在开局页“导入内容包”选择 `.sgs.mjs` 或 `.sgs`，可混选多个文件；同批文件顺序不影响依赖解析，也可先安装提供方、再导入消费者。成功保存后自动启用新包。重复 ID 不隐式升级或覆盖；取消勾选、移除及重新开局不修改作者原文件。选中上层包会包含其依赖，停用提供方会同步停用依赖者，移除提供方会级联移除依赖它的已安装外部包。失效的武将和牌组选择回到基础选择，仍合法的选择保留。

导入先读完整批次、实例化依赖图，并用 `resolvePackages`、`createBooks` 和各牌组工厂检查临时目录，全部成功后才交给存储提交。错误不会留下半安装目录。内容修改只在开局页进行，启动恢复与保存期间阻止开局及其他内容修改。

## 跨模块代码共享

提供方可命名导出函数、Window、Query 或 class；消费者从包入口导入，并在自身 `manifest.requires` 中声明该**直接依赖**：

```ts
import { provisionFinished, provisionBy, tideDrawBonus } from '@sgs/content/harbor';
```

项目 [tsconfig](../tsconfig.json) 将 `@sgs/sdk` 映射到宿主源码、`@sgs/content/*` 映射到示例源码，为编辑器提供类型。独立作者项目应将依赖入口映射到提供方源码或类型声明。类型专用 import 会擦除，不产生运行依赖；相对 import 会将辅助实现归入当前包，共享对象身份应使用 `@sgs/content/<packageId>`。

[加载器](../src/app/offline/content-modules.ts) 按代码依赖实例化，每个提供方在同一安装实例中执行一次，后续导入复用它的真实命名空间，default、命名、命名空间导入、转导出和动态导出值保持原语义。返回列表保持文件输入顺序。代码依赖缺失、循环、版本不符或未声明直接依赖时拒绝整批，保留旧目录并释放新资源；不能借用未直接声明的传递依赖。

模块初始化同步完成；普通技能函数仍可使用闭包、分支、循环与 `await`。顶层 `await`、外部动态 import、包子路径 import 和额外输出块会在构建时报错。内置规则 API 从 `@sgs/sdk` 导入，`@sgs/content/` 当前只解析已安装外部模块。

停用不销毁安装实例。恢复时从全部已保存源码重新装配一组实例，局部变量重新初始化，消费者不会连接到上一次的对象。模块初始化应只声明内容；规则状态放在 World 或显式 Lifetime。安装事务不回滚可信代码自行写入的全局或外部状态。

## 资源与所有权

普通图片 import 和 `generalViews` 可用于两种产物。`.sgs.mjs` 内联资源；`.sgs` 包含 `manifest.json`、`content.sgs.mjs` 和原始二进制 `assets/`，清单声明资源路径与 MIME，加载时检查缺失、重复及未声明文件。构建固定文件顺序与 ZIP 时间，资源不重新编码；通过 `../` 复用的入口外资源使用内容哈希生成稳定包内路径，不携带开发机绝对路径。

普通 JSON import 仍是代码数据；文件 URL 使用 `import dataUrl from './data.json?url'`，显式 `?raw` 保留文本语义。图片、音频、字体及其他显式 `?url` 资源可携带原始字节。当前不自动重写 CSS、SVG 或 Spine atlas 内部的相对媒体依赖，也没有作者 Spine 播放声明；解压和存储以完整包为单位，不承诺任意大包的流式加载或性能。

[资源租期](../src/app/offline/content-assets.ts) 持有不可变 Blob 声明，按需创建 URL：同一路径在同一实例中复用，不同实例隔离，释放幂等。源码模块 URL 在 import 后释放，资源 URL 保留到卸载。失败批次包括晚完成的加载任务都会释放新资源；保存失败保留旧目录及图片，成功替换后才释放旧资源。恢复创建新 URL，不依赖作者原文件或上一进程的 URL。

资源属于客户端内容库，不进入 World、事实、席位投影或 AI 观察。协调器不持有 Room；独立调用者须先结束使用旧目录的客户端，再卸载或替换目录。应用通过开局页边界保证这一点。

## 持久安装与恢复

[ContentLibrary](../src/app/offline/content-library.ts) 协调临时装配、保存与发布，[IndexedDB 存储](../src/app/offline/content-storage.ts) 用 `sgs-content-store/1` 记录 revision、模块 ID/名称/版本/文件名/完整源码、资源 Blob 及显式启用列表。数据复制并冻结，函数、命名空间、Blob URL、World、Room 和决策会话不写入存储。

导入、开关、级联移除与清空均在同一 readwrite 事务中比较预期 revision、提交整份目录；只有 `transaction.complete` 后才发布新目录，请求成功不等于保存成功。额度不足、存储不可用或事务中止会明确失败，保留此前可用目录和持久记录，不退回“仅本窗口安装”并声称成功。开关草稿失败后回到已提交值。

多窗口修改遇到旧 revision 会要求重载，不能覆盖新记录，也不热换另一个窗口的牌局。恢复读取全部源码与 Blob，传入当前真实 SDK，重新核对模块 ID/名称/版本和依赖，再发布目录。语法、执行、依赖、版本或记录错误不自动删除保存数据；首次失败仍保留标准目录，重载失败保留已有可用目录。

可明确重载或清空已保存内容。能读取版本时，清空仍受 revision 检查；损坏且无法读版本时，只允许清除仍损坏的值。若另一窗口已修复成有效新记录，旧窗口必须先重载，不能擦除新目录。清空不修改原文件，关闭期间已提交的记录可由下一个实例恢复，但不会复活关闭窗口的资源 URL。

## 验证与边界

规则与构建验证分别见 [包装配](../tests/scenarios/packages.test.ts)、[真实模块](../tests/scenarios/content-modules.test.ts)、[跨模块 API](../tests/scenarios/content-module-api.test.ts)、[资源字节与释放](../tests/scenarios/content-assets.test.ts) 和 [持久化协调](../tests/scenarios/content-library.test.ts)。这些场景检查真实构建产物、共享身份、技能结算、错误保留、资源所有权及事实重建。

真实 Blob 导入与 IndexedDB 事务由 [资源包浏览器场景](../tests/browser/content-bundle.spec.ts) 和 [存储浏览器场景](../tests/browser/content-storage.spec.ts) 验证；Node 场景不代替浏览器加载。[Windows 验收](../scripts/verify-windows.ps1) 使用隔离数据目录，结束第一进程后启动不同进程，从保存数据恢复并实际使用技能；[归档](../scripts/package-windows.ps1) 核对 exe、内容与对应运行证明。平台结果以 STATUS 为准，不把刷新页面当成程序重启。

基础 AI 使用受限观察与正式决策，能处理已有通用交互，不能据此推断它理解任意作者代码。自定义 Decision 进入规则层，也不自动获得客户端交互面板。模式包、完整录像和任意时点续局仍不属于当前交付承诺。

本文合并原内容包、模块导入、持久恢复、资源包及模块 API 五篇说明。原文与被修改的阅读入口逐字节保存在 `.artifacts/validation/package-docs-before.zip`，历史批次细节不再作为作者必读路径。
